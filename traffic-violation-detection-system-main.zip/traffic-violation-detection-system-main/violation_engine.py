from dataclasses import dataclass

from fsm import TrackFSM


@dataclass
class ViolationEvent:
	track_id: int
	vehicle_type: str
	violation_type: str
	timestamp: float


class ViolationEngine:
	def __init__(self, settings):
		self.fsm = TrackFSM(
			fps=settings.output_fps,
			stop_line_y=settings.stop_line_y,
			expected_direction=settings.expected_direction,
			wrongway_min_displacement_px=settings.wrongway_min_displacement_px,
			ewma_decay=0.85,
			confirm_th=0.75,
			clear_th=0.45,
		)

	def evaluate_track(self, track, helmets, signal_state, timestamp):
		active_violations, new_events, memory = self.fsm.update(
			track_id=track["track_id"],
			bottom_center=track["bottom_center"],
			bbox=track["bbox"],
			is_motorcycle=track["is_motorcycle"],
			helmets=helmets,
			signal_state=signal_state,
		)

		events = [
			ViolationEvent(
				track_id=track["track_id"],
				vehicle_type=track["class_name"],
				violation_type=evt,
				timestamp=timestamp,
			)
			for evt in new_events
		]
		return active_violations, events, memory
