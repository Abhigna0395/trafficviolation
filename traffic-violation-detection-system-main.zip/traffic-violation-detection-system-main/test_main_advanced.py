#!/usr/bin/env python
"""Test main_advanced.py with limited frames."""

import os
import yaml

# Override config to use limited frames for quick test
config_path = os.path.join("config", "config.yaml")
with open(config_path, "r", encoding="utf-8") as file:
	cfg = yaml.safe_load(file)

# Use only 30 frames for quick test
cfg['processing']['max_frames'] = 30

print("=" * 70)
print("RUNNING ADVANCED PIPELINE TEST (30 frames)")
print("=" * 70)
print(f"Config: {cfg['violation']['speed_limit_kmh']} km/h speed limit")
print(f"Device: {cfg['detectors'].get('device', 'cpu')}")
print("-" * 70)

# Import and run
from main_advanced import run_advanced_pipeline

try:
	run_advanced_pipeline(cfg)
	print("\n" + "=" * 70)
	print("✓ ADVANCED PIPELINE TEST PASSED")
	print("=" * 70)
except Exception as e:
	print(f"\n✗ Test failed: {e}")
	import traceback
	traceback.print_exc()
