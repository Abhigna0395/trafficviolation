# IEEE Paper Assets

This folder contains publication-ready figures and tables generated from model training runs and application outputs.

## Purpose
Use these assets directly in reports/papers (for example, IEEE format) to summarize model performance and real-world violation detection behavior.

## Regeneration
Run the command below from the project root to refresh all figures and tables:

```bash
python scripts/generate_ieee_assets.py
```

The script is idempotent and safely overwrites generated files with updated values.

## Key Figures
- `figures/comparison_metrics_bar.png`: Precision, Recall, F1, mAP comparison across runs.
- `figures/comparison_map50_curve.png`: mAP@50 vs epoch comparison.
- `figures/application_violation_distribution.png`: Violation-type frequency from output CSV.
- `figures/app_frames_montage.jpg`: Sample annotated output frames.
- `figures/model_plots/`: YOLO generated curves/confusion matrices copied from train runs.
- `figures/evidence_samples/`: Example evidence snapshots.

## Tables
- `tables/model_metrics_comparison.csv`: Final Precision/Recall/F1/mAP summary for each run.

## Folder Layout
```text
paper_assets/
	figures/
		app_frames/
		evidence_samples/
		model_plots/
		comparison_metrics_bar.png
		comparison_map50_curve.png
		application_violation_distribution.png
		app_frames_montage.jpg
	tables/
		model_metrics_comparison.csv
```

## Data Sources
- Train runs used: train6, train7
- Violation CSV used: output_violations.csv
- Optional video source: first available from `outputs/output.mp4`, `outputs/annotated_video.mp4`, or `outputs/annotated.mp4`.
- Evidence source: images from `outputs/violations/` (up to 8 copied).

## Notes
- Missing optional sources are skipped gracefully (for example, no video means no extracted app frames).
- To compare additional train runs, extend `run_rows_map` in `scripts/generate_ieee_assets.py`.
