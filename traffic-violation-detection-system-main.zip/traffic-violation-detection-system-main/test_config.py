#!/usr/bin/env python
import yaml
import os

# Load config
config_path = os.path.join('config', 'config.yaml')
with open(config_path, 'r', encoding='utf-8') as file:
	cfg = yaml.safe_load(file)

# Update max_frames for quick test
cfg['processing']['max_frames'] = 50

# Save to temp config
temp_config_path = 'config/config_test.yaml'
with open(temp_config_path, 'w', encoding='utf-8') as file:
	yaml.dump(cfg, file)

print(f'Created test config with max_frames=50 at {temp_config_path}')
print(f'Config max_frames: {cfg["processing"]["max_frames"]}')
