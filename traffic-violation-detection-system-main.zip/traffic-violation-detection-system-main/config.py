from dataclasses import dataclass, field


@dataclass
class Settings:
	input_video: str = "data/sample.mp4"
	output_video: str = "outputs/output.mp4"
	csv_report_path: str = "outputs/lane_violations.csv"
	evidence_dir: str = "outputs/evidence"

	frame_width: int = 1280
	frame_height: int = 720
	output_fps: int = 30
	frame_skip: int = 1
	preview: bool = False
	show_lane_debug: bool = False

	device: str = "auto"
	runtime_device: str = "cpu"

	vehicle_model_path: str = "train7/weights/best.pt"
	helmet_model_path: str = "train6/weights/best.pt"
	plate_model_path: str = r"D:\Traffic Violation Detection System\traffic-violation-system\number plate\best.pt"
	tracker_config: str = "bytetrack.yaml"

	vehicle_confidence: float = 0.35
	helmet_confidence: float = 0.15
	plate_confidence: float = 0.30
	ocr_min_score: float = 0.40
	min_plate_chars: int = 6
	ocr_languages: list[str] = field(default_factory=lambda: ["en"])
	helmet_class_names: set[str] = field(default_factory=lambda: {"helmet"})

	vehicle_class_names: set[str] = field(
		default_factory=lambda: {"car", "truck", "bus", "motorcycle", "motorbike", "auto", "rickshaw"}
	)
	class_conf_thresholds: dict[str, float] = field(
		default_factory=lambda: {
			"car": 0.40,
			"truck": 0.45,
			"bus": 0.45,
			"motorcycle": 0.35,
			"motorbike": 0.35,
			"auto": 0.35,
			"rickshaw": 0.35,
		}
	)

	lane_boundaries_x: list[int] = field(default_factory=lambda: [0, 426, 853, 1280])
	lane_persist_frames: int = 3
	lane_min_displacement_px: float = 40.0
	min_track_age_frames: int = 12
	max_track_missing_frames: int = 90
	no_helmet_confirm_frames: int = 3
	no_helmet_clear_frames: int = 2
