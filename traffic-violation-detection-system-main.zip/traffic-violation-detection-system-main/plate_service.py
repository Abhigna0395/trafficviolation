import queue
import re
import threading

from ultralytics import YOLO

try:
	import easyocr
except Exception:
	easyocr = None


class PlateService:
	def __init__(self, settings, model=None, reader=None):
		self.settings = settings
		if model is not None:
			self.model = model
		else:
			self.model = YOLO(settings.plate_model_path)

		if reader is not None:
			self.reader = reader
		else:
			if easyocr is None:
				raise RuntimeError("easyocr is required. Install with: pip install easyocr")
			use_gpu = settings.runtime_device not in {"cpu", "mps"}
			self.reader = easyocr.Reader(settings.ocr_languages, gpu=use_gpu)

		self._jobs: queue.Queue = queue.Queue()
		self._results: queue.Queue = queue.Queue()
		self._stop_event = threading.Event()
		self._worker = threading.Thread(target=self._worker_loop, daemon=True)
		self._worker.start()

	@staticmethod
	def _clean_plate(text: str) -> str:
		return re.sub(r"[^A-Z0-9]", "", text.upper())

	def submit(self, track_id: int, frame, bbox, timestamp: float, vehicle_class: str, violation_type: str = "LANE_CHANGE"):
		self._jobs.put(
			{
				"track_id": track_id,
				"frame": frame,
				"bbox": bbox,
				"timestamp": timestamp,
				"vehicle_class": vehicle_class,
				"violation_type": violation_type,
			}
		)

	def get_completed(self):
		results = []
		while True:
			try:
				results.append(self._results.get_nowait())
			except queue.Empty:
				break
		return results

	def shutdown(self):
		self._stop_event.set()
		self._jobs.put(None)
		if self._worker.is_alive():
			self._worker.join(timeout=2.0)

	def _worker_loop(self):
		while not self._stop_event.is_set():
			job = self._jobs.get()
			if job is None:
				break

			plate_number = self._detect_plate(job["frame"], job["bbox"])
			self._results.put(
				{
					"track_id": job["track_id"],
					"plate_number": plate_number,
					"timestamp": job["timestamp"],
					"vehicle_class": job["vehicle_class"],
					"violation_type": str(job.get("violation_type", "LANE_CHANGE")).upper(),
				}
			)

	def _detect_plate(self, frame, vehicle_bbox):
		x1, y1, x2, y2 = map(int, vehicle_bbox)
		x1 = max(0, x1)
		y1 = max(0, y1)
		x2 = min(frame.shape[1], x2)
		y2 = min(frame.shape[0], y2)
		if x2 <= x1 or y2 <= y1:
			return "UNKNOWN"

		vehicle_crop = frame[y1:y2, x1:x2]
		if vehicle_crop.size == 0:
			return "UNKNOWN"

		results = self.model.predict(
			vehicle_crop,
			conf=self.settings.plate_confidence,
			device=self.settings.runtime_device,
			verbose=False,
		)
		if not results:
			return "UNKNOWN"

		res = results[0]
		if res.boxes is None or len(res.boxes) == 0:
			return "UNKNOWN"

		best_box = None
		best_conf = -1.0
		for box in res.boxes:
			conf = float(box.conf[0].item())
			if conf > best_conf:
				best_conf = conf
				best_box = box
		if best_box is None:
			return "UNKNOWN"

		px1, py1, px2, py2 = map(int, best_box.xyxy[0].tolist())
		px1 = max(0, px1)
		py1 = max(0, py1)
		px2 = min(vehicle_crop.shape[1], px2)
		py2 = min(vehicle_crop.shape[0], py2)
		if px2 <= px1 or py2 <= py1:
			return "UNKNOWN"

		plate_crop = vehicle_crop[py1:py2, px1:px2]
		if plate_crop.size == 0:
			return "UNKNOWN"

		ocr_results = self.reader.readtext(plate_crop)
		if not ocr_results:
			return "UNKNOWN"

		best_text = ""
		best_score = 0.0
		for _, text, score in ocr_results:
			cleaned = self._clean_plate(text)
			if len(cleaned) < self.settings.min_plate_chars:
				continue
			if float(score) > best_score:
				best_score = float(score)
				best_text = cleaned

		if best_score < self.settings.ocr_min_score or not best_text:
			return "UNKNOWN"
		return best_text
