import csv
import os
import time
from pathlib import Path

import cv2
from ultralytics import YOLO

from config import Settings
from fsm import TrackMemoryStore
from lane_service import LaneService
from plate_service import PlateService


def resolve_device(settings: Settings) -> str:
	if settings.device != "auto":
		return settings.device
	try:
		import torch
		if torch.cuda.is_available():
			return "0"
	except Exception:
		pass
	return "cpu"


def class_threshold_ok(class_name: str, confidence: float, settings: Settings) -> bool:
	return confidence >= settings.class_conf_thresholds.get(class_name, settings.vehicle_confidence)


def format_label(track_id: int, vehicle_class: str, violated: bool) -> str:
	vcls = vehicle_class.replace("_", " ").title()
	if violated:
		return f"ID:{track_id} {vcls} LANE_CHANGE"
	return f"ID:{track_id} {vcls}"


def is_motorcycle(vehicle_class: str) -> bool:
	name = vehicle_class.lower()
	return name in {"motorcycle", "motorbike", "bike", "two_wheeler", "two-wheeler"}


def _normalize_label(text: str) -> str:
	return str(text).strip().lower().replace("_", " ")


def detect_headgear_boxes(helmet_model: YOLO, frame, settings: Settings):
	results = helmet_model.predict(
		frame,
		conf=settings.helmet_confidence,
		device=settings.runtime_device,
		verbose=False,
	)
	with_helmet_boxes = []
	without_helmet_boxes = []
	if not results:
		return with_helmet_boxes, without_helmet_boxes
	res = results[0]
	if res.boxes is None:
		return with_helmet_boxes, without_helmet_boxes
	names = res.names
	for box in res.boxes:
		cls_id = int(box.cls[0].item())
		class_name = _normalize_label(names.get(cls_id, cls_id))
		x1, y1, x2, y2 = map(float, box.xyxy[0].tolist())
		bbox = (x1, y1, x2, y2)

		# Common class names seen in helmet datasets.
		if class_name in {"helmet", "with helmet", "helmet on", "withhelmet"}:
			with_helmet_boxes.append(bbox)
		elif class_name in {"without helmet", "no helmet", "withouthelmet", "nohelmet"}:
			without_helmet_boxes.append(bbox)
		elif "without" in class_name and "helmet" in class_name:
			without_helmet_boxes.append(bbox)
		elif "helmet" in class_name:
			with_helmet_boxes.append(bbox)

	return with_helmet_boxes, without_helmet_boxes


def _box_area(box):
	x1, y1, x2, y2 = box
	return max(0.0, x2 - x1) * max(0.0, y2 - y1)


def _intersection_area(a, b):
	ax1, ay1, ax2, ay2 = a
	bx1, by1, bx2, by2 = b
	ix1 = max(ax1, bx1)
	iy1 = max(ay1, by1)
	ix2 = min(ax2, bx2)
	iy2 = min(ay2, by2)
	if ix2 <= ix1 or iy2 <= iy1:
		return 0.0
	return (ix2 - ix1) * (iy2 - iy1)


def headgear_match_score_for_vehicle(bbox, headgear_boxes):
	"""Return best headgear match score for vehicle head region.

	Score combines overlap ratio and center-in-head-region bonus for stability.
	"""
	x1, y1, x2, y2 = bbox
	w = max(1.0, x2 - x1)
	h = max(1.0, y2 - y1)

	# Expand head region slightly to tolerate detector jitter.
	head_box = (
		x1 - 0.18 * w,
		y1 - 0.06 * h,
		x2 + 0.18 * w,
		y1 + 0.55 * h,
	)
	head_area = _box_area(head_box)
	if head_area <= 0:
		return 0.0

	best_score = 0.0
	for hg_box in headgear_boxes:
		overlap = _intersection_area(head_box, hg_box)
		overlap_ratio = overlap / head_area

		hx1, hy1, hx2, hy2 = hg_box
		hx = (hx1 + hx2) * 0.5
		hy = (hy1 + hy2) * 0.5
		center_inside = head_box[0] <= hx <= head_box[2] and head_box[1] <= hy <= head_box[3]

		score = overlap_ratio + (0.08 if center_inside else 0.0)
		if score > best_score:
			best_score = score

	return best_score


def helmet_evidence_from_scores(with_helmet_score: float, without_helmet_score: float):
	"""Convert headgear match scores into no-helmet evidence in [0,1].

	Returns: (evidence, strong_no_helmet, strong_with_helmet)
	"""
	# High-confidence explicit decisions.
	if without_helmet_score >= 0.16 and with_helmet_score < 0.08:
		return 1.0, True, False
	if with_helmet_score >= 0.16 and without_helmet_score < 0.08:
		return 0.0, False, True

	# Relative preference when both classes appear.
	if without_helmet_score >= 0.08 and without_helmet_score > with_helmet_score * 1.15:
		return 0.9, False, False
	if with_helmet_score >= 0.08 and with_helmet_score > without_helmet_score * 1.15:
		return 0.1, False, False

	# Absence-based rule: if neither class is detected on rider head, bias toward no-helmet.
	if with_helmet_score < 0.04 and without_helmet_score < 0.04:
		return 0.82, False, False

	# Mild bias fallback.
	if without_helmet_score >= with_helmet_score:
		return 0.68, False, False
	return 0.32, False, False


def init_csv(csv_path: Path):
	csv_path.parent.mkdir(parents=True, exist_ok=True)
	if csv_path.exists() and csv_path.stat().st_size > 0:
		return
	with csv_path.open("w", newline="", encoding="utf-8") as f:
		writer = csv.writer(f)
		writer.writerow(["TrackID", "VehicleClass", "PlateNumber", "ViolationType", "Timestamp"])


def append_csv(csv_path: Path, row):
	with csv_path.open("a", newline="", encoding="utf-8") as f:
		writer = csv.writer(f)
		writer.writerow(row)


def save_evidence(evidence_dir: str, track_id: int, frame_index: int, frame):
	os.makedirs(evidence_dir, exist_ok=True)
	filename = f"lane_change_track_{track_id}_frame_{frame_index}.jpg"
	path = os.path.join(evidence_dir, filename)
	cv2.imwrite(path, frame)
	return path


def log_violation(csv_path: Path, violations_list: list, track_id: int, vehicle_class: str, plate_number: str, violation_type: str, timestamp_s: float):
	plateno = (plate_number or "").strip() or "UNKNOWN"
	vtype = str(violation_type).upper()
	row = [
		track_id,
		vehicle_class,
		plateno,
		vtype,
		f"{timestamp_s:.2f}",
	]
	append_csv(csv_path, row)
	violations_list.append(
		{
			"TrackID": track_id,
			"VehicleClass": vehicle_class,
			"PlateNumber": plateno,
			"ViolationType": vtype,
			"Timestamp": float(timestamp_s),
		}
	)


def load_best_training_map50(base_dir: Path):
	train_runs = sorted([p for p in base_dir.glob("train*") if p.is_dir()], key=lambda p: p.name)
	best_map50 = None
	best_run = None

	for run_dir in train_runs:
		results_path = run_dir / "results.csv"
		if not results_path.exists():
			continue
		with results_path.open("r", encoding="utf-8", newline="") as f:
			reader = csv.DictReader(f)
			for row in reader:
				value = row.get("metrics/mAP50(B)")
				if not value:
					continue
				try:
					metric = float(value)
				except (TypeError, ValueError):
					continue
				if best_map50 is None or metric > best_map50:
					best_map50 = metric
					best_run = run_dir.name

	return best_map50, best_run


def process_video(input_path, output_path, resources=None):
	settings = Settings()
	settings.input_video = str(input_path)
	settings.output_video = str(output_path)
	output_video = Path(settings.output_video)
	project_dir = Path(__file__).resolve().parent
	csv_path = output_video.with_name(f"{output_video.stem}_violations.csv")
	settings.csv_report_path = str(csv_path)
	settings.runtime_device = resolve_device(settings)
	resources = resources or {}
	best_map50, best_run = load_best_training_map50(project_dir)

	print(f"[INFO] Device: {settings.runtime_device}")
	if best_map50 is not None:
		print(f"[INFO] Model accuracy (mAP@50): {best_map50 * 100:.2f}% (source: {best_run}/results.csv)")
	else:
		print("[INFO] Model accuracy (mAP@50): N/A (no train*/results.csv found)")
	print("[INFO] Loading models...")

	vehicle_model = resources.get("vehicle_model") or YOLO(settings.vehicle_model_path)
	helmet_model = resources.get("helmet_model") or YOLO(settings.helmet_model_path)
	plate_service = PlateService(
		settings,
		model=resources.get("plate_model"),
		reader=resources.get("ocr_reader"),
	)
	memory_store = TrackMemoryStore()
	lane_service = LaneService(
		lane_boundaries_x=settings.lane_boundaries_x,
		persist_frames=settings.lane_persist_frames,
		min_displacement_px=settings.lane_min_displacement_px,
		min_track_age_frames=settings.min_track_age_frames,
	)

	cap = cv2.VideoCapture(settings.input_video)
	if not cap.isOpened():
		plate_service.shutdown()
		raise RuntimeError(f"Unable to open input video: {settings.input_video}")

	source_fps = cap.get(cv2.CAP_PROP_FPS)
	fps = settings.output_fps if settings.output_fps > 0 else (source_fps if source_fps > 0 else 30)

	output_video.parent.mkdir(parents=True, exist_ok=True)
	writer = cv2.VideoWriter(
		str(output_video),
		cv2.VideoWriter_fourcc(*"mp4v"),
		fps,
		(settings.frame_width, settings.frame_height),
	)

	init_csv(csv_path)
	violations_list = []

	frame_index = 0
	start_time = time.time()

	print("[INFO] Running lane-change detection pipeline...")
	try:
		while True:
			ok, frame = cap.read()
			if not ok:
				break

			frame_index += 1
			if settings.frame_skip > 1 and frame_index % settings.frame_skip != 0:
				continue

			frame = cv2.resize(frame, (settings.frame_width, settings.frame_height), interpolation=cv2.INTER_LINEAR)
			with_helmet_boxes, without_helmet_boxes = detect_headgear_boxes(helmet_model, frame, settings)

			results = vehicle_model.track(
				frame,
				persist=True,
				tracker=settings.tracker_config,
				conf=settings.vehicle_confidence,
				device=settings.runtime_device,
				verbose=False,
			)

			if results and results[0].boxes is not None and results[0].boxes.id is not None:
				res = results[0]
				names = res.names
				for box, tid_tensor in zip(res.boxes, res.boxes.id):
					track_id = int(tid_tensor.item())
					cls_id = int(box.cls[0].item())
					class_name = str(names.get(cls_id, cls_id)).lower()
					conf = float(box.conf[0].item())

					if class_name not in settings.vehicle_class_names:
						continue
					if not class_threshold_ok(class_name, conf, settings):
						continue

					x1, y1, x2, y2 = map(float, box.xyxy[0].tolist())
					bbox = (x1, y1, x2, y2)
					bottom_center = ((x1 + x2) * 0.5, y2)

					memory = memory_store.update_frame(track_id, class_name, bottom_center, frame_index)
					new_violation = lane_service.update_track_lane(memory, bottom_center)

					if is_motorcycle(class_name):
						with_helmet_score = headgear_match_score_for_vehicle(bbox, with_helmet_boxes)
						without_helmet_score = headgear_match_score_for_vehicle(bbox, without_helmet_boxes)
						evidence, strong_no_helmet, strong_with_helmet = helmet_evidence_from_scores(
							with_helmet_score,
							without_helmet_score,
						)
						memory.helmet_score = 0.85 * memory.helmet_score + 0.15 * evidence

						# Fast paths for strong predictions.
						if strong_no_helmet:
							memory.no_helmet_counter = max(memory.no_helmet_counter, settings.no_helmet_confirm_frames)
							memory.helmet_present_counter = 0
							memory.helmet_score = max(memory.helmet_score, 0.85)
						elif strong_with_helmet:
							memory.helmet_present_counter = max(memory.helmet_present_counter, settings.no_helmet_clear_frames)
							memory.no_helmet_counter = 0
							memory.helmet_score = min(memory.helmet_score, 0.15)

						if evidence <= 0.30:
							memory.helmet_present_counter += 1
							memory.no_helmet_counter = 0
						elif evidence >= 0.70:
							memory.no_helmet_counter += 1
							memory.helmet_present_counter = 0
						else:
							memory.no_helmet_counter = max(0, memory.no_helmet_counter - 1)
							memory.helmet_present_counter = max(0, memory.helmet_present_counter - 1)

						if memory.helmet_score >= 0.62 and memory.no_helmet_counter >= settings.no_helmet_confirm_frames:
							memory.no_helmet_confirmed = True
						elif memory.helmet_score <= 0.40 and memory.helmet_present_counter >= settings.no_helmet_clear_frames:
							memory.no_helmet_confirmed = False
					else:
						memory.no_helmet_confirmed = False
						memory.helmet_score = 0.85 * memory.helmet_score
						memory.no_helmet_counter = 0
						memory.helmet_present_counter = 0

					if new_violation and not memory.lane_violation_logged:
						if memory.plate_extracted:
							log_violation(
								csv_path,
								violations_list,
								track_id,
								class_name,
								memory.plate_number,
								"LANE_CHANGE",
								frame_index / fps,
							)
							memory.lane_violation_logged = True
						elif not memory.plate_job_submitted:
							memory.plate_job_submitted = True
							plate_service.submit(
								track_id=track_id,
								frame=frame.copy(),
								bbox=bbox,
								timestamp=frame_index / fps,
								vehicle_class=class_name,
								violation_type="LANE_CHANGE",
							)
							save_evidence(settings.evidence_dir, track_id, frame_index, frame)

					if memory.no_helmet_confirmed and not memory.no_helmet_violation_logged:
						if memory.plate_extracted:
							log_violation(
								csv_path,
								violations_list,
								track_id,
								class_name,
								memory.plate_number,
								"NO_HELMET",
								frame_index / fps,
							)
							memory.no_helmet_violation_logged = True
						elif not memory.plate_job_submitted:
							memory.plate_job_submitted = True
							plate_service.submit(
								track_id=track_id,
								frame=frame.copy(),
								bbox=bbox,
								timestamp=frame_index / fps,
								vehicle_class=class_name,
								violation_type="NO_HELMET",
							)
							save_evidence(settings.evidence_dir, track_id, frame_index, frame)

					x1i, y1i, x2i, y2i = map(int, bbox)
					any_violation = memory.lane_violation_confirmed or memory.no_helmet_confirmed
					color = (0, 0, 255) if any_violation else (0, 200, 0)
					cv2.rectangle(frame, (x1i, y1i), (x2i, y2i), color, 2)
					label = format_label(track_id, class_name, memory.lane_violation_confirmed)
					if memory.no_helmet_confirmed:
						label = f"{label} NO_HELMET"
					cv2.putText(
						frame,
						label,
						(x1i, max(18, y1i - 8)),
						cv2.FONT_HERSHEY_SIMPLEX,
						0.58,
						color,
						2,
						cv2.LINE_AA,
					)

					if settings.show_lane_debug:
						debug_text = (
							f"L:{memory.lane_index} P:{memory.previous_lane} "
							f"C:{memory.lane_change_counter} A:{memory.frames_seen}"
						)
						cv2.putText(
							frame,
							debug_text,
							(x1i, min(settings.frame_height - 30, y2i + 42)),
							cv2.FONT_HERSHEY_SIMPLEX,
							0.48,
							(200, 255, 255),
							1,
							cv2.LINE_AA,
						)

					if memory.plate_number:
						cv2.putText(
							frame,
							f"PLATE: {memory.plate_number}",
							(x1i, min(settings.frame_height - 10, y2i + 22)),
							cv2.FONT_HERSHEY_SIMPLEX,
							0.55,
							(255, 255, 255),
							2,
							cv2.LINE_AA,
						)

			completed = plate_service.get_completed()
			for item in completed:
				track_id = int(item["track_id"])
				plate_number = item["plate_number"]
				violation_type = str(item.get("violation_type", "LANE_CHANGE")).upper()
				memory_store.set_plate_result(track_id, plate_number)
				memory = memory_store.get(track_id)
				if not memory:
					continue
				if violation_type == "NO_HELMET" and not memory.no_helmet_violation_logged:
					log_violation(
						csv_path,
						violations_list,
						track_id,
						item["vehicle_class"],
						plate_number,
						violation_type,
						float(item["timestamp"]),
					)
					memory.no_helmet_violation_logged = True
				elif violation_type == "LANE_CHANGE" and not memory.lane_violation_logged:
					log_violation(
						csv_path,
						violations_list,
						track_id,
						item["vehicle_class"],
						plate_number,
						violation_type,
						float(item["timestamp"]),
					)
					memory.lane_violation_logged = True

				memory.violation_logged = memory.lane_violation_logged and memory.no_helmet_violation_logged

			for lane_x in settings.lane_boundaries_x:
				cv2.line(frame, (int(lane_x), 0), (int(lane_x), settings.frame_height), (255, 255, 0), 1)

			elapsed = time.time() - start_time
			fps_now = frame_index / elapsed if elapsed > 0 else 0.0
			cv2.putText(
				frame,
				f"FPS: {fps_now:.1f}",
				(12, 28),
				cv2.FONT_HERSHEY_SIMPLEX,
				0.8,
				(0, 255, 255),
				2,
				cv2.LINE_AA,
			)

			writer.write(frame)

			memory_store.prune(frame_index, settings.max_track_missing_frames)

			if settings.preview:
				cv2.imshow("Traffic Violation Detection - Lane Change", frame)
				if cv2.waitKey(1) & 0xFF == ord("q"):
					break
	finally:
		cap.release()
		writer.release()
		plate_service.shutdown()
		if settings.preview:
			cv2.destroyAllWindows()

	print(f"[INFO] Completed. Output video: {output_video}")
	print(f"[INFO] CSV report: {csv_path}")
	if best_map50 is not None:
		print(f"[INFO] Model accuracy (mAP@50): {best_map50 * 100:.2f}% (source: {best_run}/results.csv)")
	else:
		print("[INFO] Model accuracy (mAP@50): N/A (no train*/results.csv found)")
	return violations_list


def main():
	settings = Settings()
	process_video(settings.input_video, settings.output_video)


if __name__ == "__main__":
	main()
