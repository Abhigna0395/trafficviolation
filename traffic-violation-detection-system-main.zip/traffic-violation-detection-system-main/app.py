import csv
import hashlib
import os
import tempfile
from pathlib import Path

import streamlit as st
from ultralytics import YOLO

from config import Settings
from main import process_video, resolve_device

try:
	import easyocr
except Exception:
	easyocr = None

try:
	import cv2
except Exception:
	cv2 = None


st.set_page_config(page_title="Traffic Violation Detection System", layout="wide")


@st.cache_resource
def get_cached_resources(device, vehicle_model_path, helmet_model_path, plate_model_path, ocr_languages):
	vehicle_model = YOLO(vehicle_model_path)
	helmet_model = YOLO(helmet_model_path)
	plate_model = YOLO(plate_model_path)
	if easyocr is None:
		raise RuntimeError("easyocr is required. Install with: pip install easyocr")
	ocr_reader = easyocr.Reader(ocr_languages, gpu=device not in {"cpu", "mps"})
	return {
		"vehicle_model": vehicle_model,
		"helmet_model": helmet_model,
		"plate_model": plate_model,
		"ocr_reader": ocr_reader,
	}



def _init_state():
	defaults = {
		"processing": False,
		"processed": False,
		"uploaded_path": "",
		"uploaded_name": "",
		"uploaded_sig": "",
		"output_path": "",
		"csv_path": "",
		"violations": [],
		"last_processed_sig": "",
	}
	for key, value in defaults.items():
		if key not in st.session_state:
			st.session_state[key] = value



def _file_signature(uploaded_file) -> str:
	payload = uploaded_file.getvalue()
	h = hashlib.md5()
	h.update(uploaded_file.name.encode("utf-8", errors="ignore"))
	h.update(str(len(payload)).encode("utf-8"))
	h.update(payload[:1024 * 512])
	return h.hexdigest()



def _save_upload(uploaded_file) -> str:
	tmp_dir = Path(tempfile.gettempdir()) / "traffic_violation_streamlit"
	tmp_dir.mkdir(parents=True, exist_ok=True)
	input_path = tmp_dir / uploaded_file.name
	with open(input_path, "wb") as f:
		f.write(uploaded_file.getbuffer())
	return str(input_path)



def _read_csv_rows(csv_path: str):
	if not csv_path or not os.path.exists(csv_path):
		return []
	rows = []
	with open(csv_path, "r", encoding="utf-8", newline="") as f:
		reader = csv.DictReader(f)
		for row in reader:
			rows.append(row)
	return rows


def _read_preview_frame(video_path: str):
	if cv2 is None or not video_path or not os.path.exists(video_path):
		return None
	cap = cv2.VideoCapture(video_path)
	if not cap.isOpened():
		return None
	ok, frame = cap.read()
	cap.release()
	if not ok or frame is None:
		return None
	frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	return frame_rgb



def _extract_plates(rows):
	plates = []
	for row in rows:
		plate = (row.get("PlateNumber") or "").strip()
		if plate and plate.upper() != "UNKNOWN":
			plates.append(plate)
	return sorted(set(plates))


def _load_model_accuracy():
	base_dir = Path(__file__).resolve().parent
	train_runs = sorted([p for p in base_dir.glob("train*") if p.is_dir()], key=lambda p: p.name)
	if not train_runs:
		return None

	best_map50 = None
	best_run_name = None
	for run_dir in train_runs:
		results_path = run_dir / "results.csv"
		if not results_path.exists():
			continue
		with results_path.open("r", encoding="utf-8", newline="") as f:
			reader = csv.DictReader(f)
			for row in reader:
				value = row.get("metrics/mAP50(B)")
				if not value:
					continue
				try:
					metric = float(value)
				except (TypeError, ValueError):
					continue
				if best_map50 is None or metric > best_map50:
					best_map50 = metric
					best_run_name = run_dir.name

	if best_map50 is None:
		return None

	return {
		"run": best_run_name,
		"map50": best_map50,
	}



def _render_videos(uploaded_path: str, output_path: str):
	left, right = st.columns(2)
	with left:
		st.subheader("Uploaded Video")
		if uploaded_path and os.path.exists(uploaded_path):
			st.video(uploaded_path)
		else:
			st.info("Upload a video to preview input.")
	with right:
		st.subheader("Processed Video (Violation Bounding Boxes)")
		if output_path and os.path.exists(output_path):
			st.video(output_path)
			st.caption("Red boxes indicate confirmed violations.")
			preview = _read_preview_frame(output_path)
			if preview is not None:
				st.image(preview, caption="Preview frame from processed output", use_container_width=True)
			with open(output_path, "rb") as f:
				st.download_button(
					"Download Processed Video",
					data=f.read(),
					file_name=Path(output_path).name,
					mime="video/mp4",
				)
		else:
			st.info("Processed output will appear here.")



def _render_report(rows):
	st.subheader("Violation Report")
	if not rows:
		st.info("No violations detected.")
		return
	st.dataframe(rows, use_container_width=True)



def main_ui():
	_init_state()
	settings = Settings()
	settings.runtime_device = resolve_device(settings)
	resources = get_cached_resources(
		device=settings.runtime_device,
		vehicle_model_path=settings.vehicle_model_path,
		helmet_model_path=settings.helmet_model_path,
		plate_model_path=settings.plate_model_path,
		ocr_languages=settings.ocr_languages,
	)

	st.title("Traffic Violation Detection System")
	st.caption("Upload a video, then click Process Video to detect and display violation bounding boxes.")
	uploaded_file = st.file_uploader("Upload traffic video", type=["mp4", "avi", "mov"])

	if uploaded_file is not None:
		file_sig = _file_signature(uploaded_file)
		if file_sig != st.session_state.uploaded_sig:
			st.session_state.uploaded_path = _save_upload(uploaded_file)
			st.session_state.uploaded_name = uploaded_file.name
			st.session_state.uploaded_sig = file_sig
			st.session_state.processed = False
			st.session_state.output_path = ""
			st.session_state.csv_path = ""
			st.session_state.violations = []

	if st.session_state.processing:
		st.warning("System Status: Processing")
	elif st.session_state.processed:
		st.success("System Status: Completed")
	else:
		st.info("System Status: Idle")

	button_disabled = st.session_state.processing or not st.session_state.uploaded_path
	process_clicked = st.button("Process Video and Show Violation Boxes", disabled=button_disabled)

	if process_clicked:
		if not st.session_state.uploaded_path or not os.path.exists(st.session_state.uploaded_path):
			st.error("Please upload a video before processing.")
		else:
			st.info("Running detection and drawing violation bounding boxes...")
			current_sig = st.session_state.uploaded_sig
			if st.session_state.last_processed_sig == current_sig and st.session_state.output_path and os.path.exists(st.session_state.output_path):
				st.info("This video is already processed. Showing cached result.")
				st.session_state.processed = True
			else:
				st.session_state.processing = True
				input_path = st.session_state.uploaded_path
				input_stem = Path(input_path).stem
				output_dir = Path(tempfile.gettempdir()) / "traffic_violation_streamlit"
				output_dir.mkdir(parents=True, exist_ok=True)
				output_path = str(output_dir / f"{input_stem}_processed.mp4")
				csv_path = str(output_dir / f"{input_stem}_processed_violations.csv")

				try:
					with st.spinner("Processing video... Please wait"):
						violations = process_video(input_path, output_path, resources=resources)
					if not os.path.exists(output_path):
						raise RuntimeError("Processed video file was not created. Please try again with an MP4 input.")
					st.session_state.output_path = output_path
					st.session_state.csv_path = csv_path
					st.session_state.violations = violations or _read_csv_rows(csv_path)
					st.session_state.processed = True
					st.session_state.last_processed_sig = current_sig
				except Exception as exc:
					st.error(f"Processing failed: {exc}")
				finally:
					st.session_state.processing = False

	_render_videos(st.session_state.uploaded_path, st.session_state.output_path)

	rows = st.session_state.violations
	if not rows and st.session_state.csv_path:
		rows = _read_csv_rows(st.session_state.csv_path)
	model_accuracy = _load_model_accuracy()

	st.markdown("### Summary")
	col1, col2, col3 = st.columns(3)
	with col1:
		st.metric("Total Violations", len(rows))
	with col2:
		plates = _extract_plates(rows)
		st.write("Detected Plates:")
		if plates:
			st.write(", ".join(plates))
		else:
			st.write("No valid plate numbers detected.")
	with col3:
		if model_accuracy is None:
			st.metric("Model Accuracy (mAP@50)", "N/A")
		else:
			st.metric("Model Accuracy (mAP@50)", f"{model_accuracy['map50'] * 100:.2f}%")
			st.caption(f"From {model_accuracy['run']}/results.csv")

	_render_report(rows)

	if st.session_state.csv_path and os.path.exists(st.session_state.csv_path):
		with open(st.session_state.csv_path, "rb") as f:
			st.download_button(
				"Download Report",
				data=f.read(),
				file_name=Path(st.session_state.csv_path).name,
				mime="text/csv",
			)


if __name__ == "__main__":
	main_ui()
