from collections import deque
from dataclasses import dataclass, field


@dataclass
class TrackMemory:
	track_id: int
	vehicle_class: str
	centroid_history: deque = field(default_factory=lambda: deque(maxlen=8))
	previous_lane: int | None = None
	lane_index: int | None = None
	lane_change_counter: int = 0
	lane_violation_confirmed: bool = False
	plate_extracted: bool = False
	plate_number: str = ""
	violation_type: str = ""
	frames_seen: int = 0
	helmet_score: float = 0.0
	no_helmet_counter: int = 0
	helmet_present_counter: int = 0
	no_helmet_confirmed: bool = False

	pending_lane_index: int | None = None
	pending_start_point: tuple[float, float] | None = None
	plate_job_submitted: bool = False
	violation_logged: bool = False
	lane_violation_logged: bool = False
	no_helmet_violation_logged: bool = False
	last_seen_frame: int = 0


class TrackMemoryStore:
	def __init__(self):
		self._tracks: dict[int, TrackMemory] = {}

	def get_or_create(self, track_id: int, vehicle_class: str) -> TrackMemory:
		memory = self._tracks.get(track_id)
		if memory is None:
			memory = TrackMemory(track_id=track_id, vehicle_class=vehicle_class)
			self._tracks[track_id] = memory
		return memory

	def update_frame(self, track_id: int, vehicle_class: str, bottom_center: tuple[float, float], frame_index: int) -> TrackMemory:
		memory = self.get_or_create(track_id, vehicle_class)
		memory.vehicle_class = vehicle_class
		memory.frames_seen += 1
		memory.centroid_history.append(bottom_center)
		memory.last_seen_frame = frame_index
		return memory

	def set_plate_result(self, track_id: int, plate_number: str):
		memory = self._tracks.get(track_id)
		if memory is None:
			return
		memory.plate_number = plate_number
		memory.plate_extracted = True
		memory.plate_job_submitted = False

	def all_tracks(self):
		return self._tracks.values()

	def get(self, track_id: int) -> TrackMemory | None:
		return self._tracks.get(track_id)

	def prune(self, current_frame: int, max_missing_frames: int):
		to_remove = []
		for track_id, memory in self._tracks.items():
			if current_frame - memory.last_seen_frame > max_missing_frames:
				to_remove.append(track_id)
		for track_id in to_remove:
			del self._tracks[track_id]
