"""
Save violation evidence as video clips instead of single frames.
Captures frames before and after violation detection.
"""
import os
from collections import deque
try:
	import cv2
except ImportError:
	cv2 = None


class VideoEvidenceSaver:
	"""Save violation evidence as short video clips."""

	def __init__(self, evidence_dir, fps=30, duration_before_s=5, duration_after_s=5):
		"""
		Initialize video evidence saver.
		
		Args:
			evidence_dir: Directory to save video clips
			fps: Video frames per second
			duration_before_s: Seconds before violation to capture
			duration_after_s: Seconds after violation to capture
		"""
		self.evidence_dir = evidence_dir
		self.fps = int(fps)
		self.duration_before_s = float(duration_before_s)
		self.duration_after_s = float(duration_after_s)
		self.frames_before = int(self.duration_before_s * self.fps)
		self.frames_after = int(self.duration_after_s * self.fps)
		
		os.makedirs(evidence_dir, exist_ok=True)
		
		# Frame buffer: store last N frames
		self.frame_buffer = deque(maxlen=self.frames_before)

	def add_frame(self, frame):
		"""Add frame to rolling buffer."""
		if cv2 is None:
			return
		self.frame_buffer.append(frame.copy())

	def save_violation_clip(self, violation_key, violation_type, frame, frames_after_list=None):
		"""
		Save violation as video clip.
		
		Args:
			violation_key: Unique identifier (e.g., "track_20_wrong_way")
			violation_type: Type of violation
			frame: Current frame (violation occurs here)
			frames_after_list: Frames to append after violation (optional, for real-time capture)
		
		Returns:
			str: Path to saved video, or None if failed
		"""
		if cv2 is None:
			return None
		
		height, width = frame.shape[:2]
		
		# Filename
		filename = f"{violation_type}_{violation_key}.avi"
		filepath = os.path.join(self.evidence_dir, filename)
		
		# Create writer
		fourcc = cv2.VideoWriter_fourcc(*'MJPG')
		writer = cv2.VideoWriter(filepath, fourcc, self.fps, (width, height))
		if not writer.isOpened():
			return None
		
		# Write buffered frames (before violation)
		for buffered_frame in self.frame_buffer:
			writer.write(buffered_frame)
		
		# Write current frame
		writer.write(frame)
		
		# Write frames after violation (if provided during capture)
		if frames_after_list:
			for after_frame in frames_after_list[:self.frames_after]:
				writer.write(after_frame)
		
		writer.release()
		return filepath

	def clear_buffer(self):
		"""Clear frame buffer."""
		self.frame_buffer.clear()
