"""
Advanced speed estimation using homography transformation.
Converts pixel-space movement to real-world distance using reference calibration.
"""
import math
from collections import deque


class HomographySpeedEstimator:
	"""
	Estimate vehicle speed using homography-based calibration.
	Requires reference points (e.g., known road markings) for calibration.
	"""
	
	def __init__(self, pixels_per_meter=8.0, fps=30.0, smoothing_window=5):
		"""
		Initialize speed estimator.
		
		Args:
			pixels_per_meter: Calibration constant (pixels to real-world conversion)
			fps: Video frames per second
			smoothing_window: Number of frames for speed smoothing (moving average)
		"""
		self.pixels_per_meter = float(pixels_per_meter)
		self.fps = float(fps)
		self.smoothing_window = int(smoothing_window)
		
		self._track_history = {}  # track_id -> deque of (x, y, timestamp)
		self._speed_history = {}  # track_id -> deque of speeds for smoothing
	
	def update(self, track_id, centroid, timestamp):
		"""
		Update speed estimate for a tracked object.
		
		Args:
			track_id: Unique track identifier
			centroid: (x, y) center point
			timestamp: Frame timestamp
		
		Returns:
			Smoothed speed in km/h
		"""
		if track_id not in self._track_history:
			self._track_history[track_id] = deque(maxlen=2)
			self._speed_history[track_id] = deque(maxlen=self.smoothing_window)
		
		history = self._track_history[track_id]
		speed_hist = self._speed_history[track_id]
		
		# Add current position
		history.append((centroid[0], centroid[1], timestamp))
		
		# Need at least 2 positions to compute speed
		if len(history) < 2:
			return 0.0
		
		prev_x, prev_y, prev_ts = history[0]
		curr_x, curr_y, curr_ts = history[1]
		
		# Compute movement in pixels
		dx = curr_x - prev_x
		dy = curr_y - prev_y
		pixel_distance = math.sqrt(dx * dx + dy * dy)
		
		# Compute time delta
		time_delta = curr_ts - prev_ts
		if time_delta <= 0:
			return 0.0
		
		# Convert pixel distance to real-world distance
		real_distance = pixel_distance / self.pixels_per_meter  # meters
		
		# Compute speed: distance / time * 3.6 (m/s to km/h)
		speed_mps = real_distance / time_delta
		speed_kmh = speed_mps * 3.6
		
		# Add to smoothing buffer
		speed_hist.append(speed_kmh)
		
		# Return smoothed speed (moving average)
		if len(speed_hist) > 0:
			return sum(speed_hist) / len(speed_hist)
		
		return speed_kmh
	
	def reset(self, track_id):
		"""Reset history for a track."""
		self._track_history.pop(track_id, None)
		self._speed_history.pop(track_id, None)
	
	def get_track_history(self, track_id):
		"""Get centroid history for a track."""
		return list(self._track_history.get(track_id, []))
