"""
Production-quality frame annotation with FPS and violation details.
- Color-coded bounding boxes per violation type
- FPS counter
- Traffic light state display
- Violation labels with severity
"""
import time
try:
	import cv2
except ImportError:
	cv2 = None


class AdvancedAnnotator:
	"""Production-quality frame annotation."""

	# Violation color scheme (BGR)
	VIOLATION_COLORS = {
		"speeding": (0, 165, 255),      # Orange
		"red_light": (128, 0, 128),     # Purple
		"wrong_way": (0, 0, 255),       # Red
		"no_helmet": (255, 0, 0),       # Blue
		"illegal_parking": (0, 255, 255),  # Cyan
		"default": (0, 200, 0),         # Green
	}

	# Severity colors (for severity indicator)
	SEVERITY_COLORS = {
		"high": (0, 0, 255),      # Red
		"medium": (0, 165, 255),  # Orange
		"low": (0, 255, 0),       # Green
	}

	def __init__(self, font_scale=0.6, line_thickness=2):
		"""
		Initialize annotator.
		
		Args:
			font_scale: Font scaling factor
			line_thickness: Bounding box line thickness
		"""
		self.font_scale = float(font_scale)
		self.line_thickness = int(line_thickness)
		self._fps_samples = []
		self._last_time = None

	def annotate_frame(self, frame, detections, traffic_light_state="unknown", fps=None):
		"""
		Annotate frame with bounding boxes, FPS, and traffic light state.
		
		Args:
			frame: Input frame (will be modified in-place)
			detections: List of detection dicts with track_id, bbox, violations
			traffic_light_state: Current traffic light state
			fps: Pre-computed FPS (if None, computed internally)
		
		Returns:
			Annotated frame
		"""
		if cv2 is None:
			return frame

		# Draw detections
		for detection in detections:
			self._draw_detection(frame, detection)

		# Draw traffic light state
		self._draw_traffic_light_state(frame, traffic_light_state)

		# Draw FPS
		if fps is not None:
			self._draw_fps(frame, fps)

		return frame

	def _draw_detection(self, frame, detection):
		"""Draw single detection with violations."""
		if cv2 is None:
			return

		x1, y1, x2, y2 = map(int, detection["bbox"])
		track_id = detection.get("track_id", "?")
		violations = detection.get("violations", [])
		speed_kmh = detection.get("speed_kmh")
		class_name = detection.get("class_name")

		# Determine color based on viola violation priority
		color = self._get_violation_color(violations)

		# Draw bounding box
		cv2.rectangle(frame, (x1, y1), (x2, y2), color, self.line_thickness)

		# Build label
		label_parts = [f"ID{track_id}"]
		if class_name:
			label_parts.append(class_name)
		if speed_kmh is not None:
			label_parts.append(f"{speed_kmh:.1f}km/h")

		# Add primary violation to label
		if violations:
			violation_type = violations[0].get("type", "?")
			severity = violations[0].get("severity", "medium")
			label_parts.append(violation_type.replace("_", " ").upper())

		label = " | ".join(label_parts)

		# Draw label background and text
		text_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, self.font_scale, 1)[0]
		label_y = max(15, y1 - 8)
		cv2.rectangle(
			frame,
			(x1, label_y - text_size[1] - 3),
			(x1 + text_size[0], label_y + 3),
			color,
			-1
		)
		cv2.putText(
			frame,
			label,
			(x1, label_y),
			cv2.FONT_HERSHEY_SIMPLEX,
			self.font_scale,
			(255, 255, 255),  # White text
			1,
			cv2.LINE_AA,
		)

	def _draw_traffic_light_state(self, frame, state):
		"""Draw traffic light state indicator in top-right corner."""
		if cv2 is None or state == "unknown":
			return

		state_text = f"Signal: {state.upper()}"
		color = {
			"red": (0, 0, 255),
			"yellow": (0, 165, 255),
			"green": (0, 255, 0),
		}.get(state.lower(), (200, 200, 200))

		text_size = cv2.getTextSize(state_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
		x = frame.shape[1] - text_size[0] - 10
		y = 30

		cv2.rectangle(frame, (x - 5, y - text_size[1] - 5), (x + text_size[0] + 5, y + 5), color, -1)
		cv2.putText(
			frame,
			state_text,
			(x, y),
			cv2.FONT_HERSHEY_SIMPLEX,
			0.7,
			(255, 255, 255),
			2,
			cv2.LINE_AA,
		)

	def _draw_fps(self, frame, fps):
		"""Draw FPS counter in top-left corner."""
		if cv2 is None:
			return

		fps_text = f"FPS: {fps:.1f}"
		text_size = cv2.getTextSize(fps_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]

		cv2.rectangle(frame, (5, 10), (15 + text_size[0], 35 + text_size[1]), (0, 0, 0), -1)
		cv2.putText(
			frame,
			fps_text,
			(10, 30),
			cv2.FONT_HERSHEY_SIMPLEX,
			0.7,
			(0, 255, 0),
			2,
			cv2.LINE_AA,
		)

	def _get_violation_color(self, violations):
		"""Get color for violation set (priority-based)."""
		if not violations:
			return self.VIOLATION_COLORS["default"]

		priority = ["red_light", "wrong_way", "speeding", "no_helmet", "illegal_parking"]
		for vtype in priority:
			if any(v.get("type") == vtype for v in violations):
				return self.VIOLATION_COLORS.get(vtype, self.VIOLATION_COLORS["default"])

		return self.VIOLATION_COLORS["default"]

	def compute_fps(self, current_time=None):
		"""
		Compute moving average FPS (20-frame window).
		
		Args:
			current_time: Current timestamp (if None, uses time.time())
		
		Returns:
			Estimated FPS (float)
		"""
		if current_time is None:
			current_time = time.time()

		if self._last_time is None:
			self._last_time = current_time
			return 0.0

		dt = current_time - self._last_time
		self._last_time = current_time

		if dt <= 0:
			return 0.0

		fps = 1.0 / dt
		self._fps_samples.append(fps)

		# Keep only last 20 samples
		if len(self._fps_samples) > 20:
			self._fps_samples.pop(0)

		# Return average
		return sum(self._fps_samples) / len(self._fps_samples)
