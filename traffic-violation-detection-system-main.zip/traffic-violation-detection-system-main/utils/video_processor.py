import os
import time

import numpy as np


try:
	import cv2
except ImportError:
	cv2 = None


class VideoProcessor:
	def __init__(self, video_path, max_frames=None, frame_skip=1):
		"""
		Initialize video processor.
		
		Args:
			video_path: Path to input video file
			max_frames: Maximum frames to process. None means process entire video.
			frame_skip: Frame skip interval (e.g., 1 = every frame, 2 = every other frame)
		"""
		self.video_path = video_path
		self.max_frames = max_frames  # None means no limit (process full video)
		self.frame_skip = max(frame_skip, 1)

	def create_writer(self, output_path, frame_shape, fps=30):
		if cv2 is None:
			return None

		height, width = frame_shape[:2]
		fourcc = cv2.VideoWriter_fourcc(*"mp4v")
		writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
		return writer if writer.isOpened() else None

	def iter_frames(self):
		"""
		Iterate through video frames until EOF or max_frames limit.
		
		Yields:
			(frame_index, frame, timestamp) tuples
		
		Logs:
			Total frames processed and video duration at end of iteration
		"""
		total_frames = 0
		start_time = time.time()
		
		if cv2 is not None and os.path.exists(self.video_path):
			cap = cv2.VideoCapture(self.video_path)
			fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
			frame_index = 0
			
			# Process frames until EOF or max_frames limit
			while cap.isOpened():
				success, frame = cap.read()
				if not success:
					break
				
				# Check max_frames limit if specified
				if self.max_frames is not None and total_frames >= self.max_frames:
					break

				if frame_index % self.frame_skip == 0:
					yield frame_index, frame, time.time()
					total_frames += 1
				
				frame_index += 1

			cap.release()
			
			# Log processing summary
			elapsed = time.time() - start_time
			video_duration = frame_index / fps if fps > 0 else 0
			print(
				f"[INFO] Video processing complete: "
				f"{total_frames} frames processed (out of {frame_index} total), "
				f"video duration: {video_duration:.2f}s, "
				f"processing time: {elapsed:.2f}s"
			)
			return

		# Fallback: generate blank frames for a mock pipeline
		print("[WARNING] Video file not found or OpenCV unavailable; using mock frames")
		height, width = 720, 1280
		mock_limit = self.max_frames if self.max_frames is not None else 100
		
		for frame_index in range(0, mock_limit, self.frame_skip):
			frame = np.zeros((height, width, 3), dtype=np.uint8)
			yield frame_index, frame, time.time()
			total_frames += 1
		
		elapsed = time.time() - start_time
		print(
			f"[INFO] Mock frame generation complete: "
			f"{total_frames} frames generated, "
			f"processing time: {elapsed:.2f}s"
		)
