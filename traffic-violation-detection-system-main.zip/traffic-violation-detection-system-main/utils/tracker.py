import math


class SimpleTracker:
	def __init__(self, max_distance=60, max_missed=30):
		self.max_distance = float(max_distance)
		self.max_missed = int(max_missed)
		self._next_id = 1
		self._tracks = {}

	def update(self, detections):
		if not detections:
			self._mark_missed(set())
			return []

		centers = [self._center(det["bbox"]) for det in detections]
		track_ids = list(self._tracks.keys())
		assigned_tracks = set()
		assigned_dets = set()

		while True:
			best = None
			for det_idx, center in enumerate(centers):
				if det_idx in assigned_dets:
					continue
				for track_id in track_ids:
					if track_id in assigned_tracks:
						continue
					track_center = self._tracks[track_id]["center"]
					distance = math.hypot(center[0] - track_center[0], center[1] - track_center[1])
					if best is None or distance < best[0]:
						best = (distance, det_idx, track_id)

			if best is None or best[0] > self.max_distance:
				break

			distance, det_idx, track_id = best
			assigned_dets.add(det_idx)
			assigned_tracks.add(track_id)
			detections[det_idx]["track_id"] = track_id
			detections[det_idx]["center"] = centers[det_idx]
			self._tracks[track_id]["center"] = centers[det_idx]
			self._tracks[track_id]["missed"] = 0

		for det_idx, detection in enumerate(detections):
			if det_idx in assigned_dets:
				continue
			track_id = self._next_id
			self._next_id += 1
			center = centers[det_idx]
			detection["track_id"] = track_id
			detection["center"] = center
			self._tracks[track_id] = {"center": center, "missed": 0}

		self._mark_missed(assigned_tracks)
		return detections

	def _mark_missed(self, updated_tracks):
		for track_id in list(self._tracks.keys()):
			if track_id in updated_tracks:
				continue
			self._tracks[track_id]["missed"] += 1
			if self._tracks[track_id]["missed"] > self.max_missed:
				del self._tracks[track_id]

	def _center(self, bbox):
		x1, y1, x2, y2 = bbox
		return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)
