import os
import sqlite3
from datetime import datetime


class ViolationDatabase:
	def __init__(self, db_path):
		os.makedirs(os.path.dirname(db_path), exist_ok=True)
		self.db_path = db_path
		self._init_schema()

	def _init_schema(self):
		with sqlite3.connect(self.db_path) as conn:
			conn.execute(
				"""
				CREATE TABLE IF NOT EXISTS violations (
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					timestamp TEXT NOT NULL,
					track_id INTEGER,
					plate_number TEXT,
					vehicle_class TEXT,
					violation_type TEXT NOT NULL,
					violation_detail TEXT,
					speed_kmh REAL,
					location TEXT,
					image_path TEXT,
					fine_amount REAL DEFAULT 0.0,
					status TEXT DEFAULT 'pending',
					frame_index INTEGER,
					bbox TEXT
				)
				"""
			)
			self._ensure_columns(conn)
			conn.commit()

	def _ensure_columns(self, conn):
		columns = {
			"vehicle_class": "TEXT",
			"violation_detail": "TEXT",
			"bbox": "TEXT",
			"plate_number": "TEXT",
			"location": "TEXT",
			"image_path": "TEXT",
			"speed_kmh": "REAL",
			"frame_index": "INTEGER",
			"fine_amount": "REAL DEFAULT 0.0",
			"status": "TEXT DEFAULT 'pending'",
		}
		existing = {
			row[1]
			for row in conn.execute("PRAGMA table_info(violations)").fetchall()
		}
		for column, col_type in columns.items():
			if column not in existing:
				conn.execute(f"ALTER TABLE violations ADD COLUMN {column} {col_type}")

	def insert_violation(
		self,
		track_id,
		plate_number,
		violation_type,
		speed_kmh,
		frame_index,
		vehicle_class=None,
		violation_detail=None,
		bbox=None,
		location=None,
		image_path=None,
		fine_amount=0.0,
		status="pending",
	):
		bbox_text = None
		if bbox is not None:
			bbox_text = ",".join(str(round(value, 2)) for value in bbox)
		with sqlite3.connect(self.db_path) as conn:
			conn.execute(
				"""
				INSERT INTO violations (
					timestamp,
					track_id,
					plate_number,
					vehicle_class,
					violation_type,
					violation_detail,
					speed_kmh,
					location,
					image_path,
					fine_amount,
					status,
					frame_index,
					bbox
				)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
				""",
				(
					datetime.utcnow().isoformat(timespec="seconds"),
					track_id,
					plate_number,
					vehicle_class,
					violation_type,
					violation_detail,
					speed_kmh,
					location,
					image_path,
					fine_amount,
					status,
					frame_index,
					bbox_text,
				),
			)
			conn.commit()
