"""
Temporal filtering and smoothing utilities.
- Majority voting across frame windows
- Exponential smoothing
- Denoising filters
"""
from collections import deque
from functools import lru_cache


class MajorityVoter:
	"""
	Keep history of states and return majority vote.
	Useful for reducing noise in detection results (e.g., traffic light color).
	"""
	
	def __init__(self, window_size=5):
		"""
		Initialize majority voter.
		
		Args:
			window_size: Number of frames to keep history
		"""
		self.window_size = window_size
		self._history = deque(maxlen=window_size)
	
	def update(self, state):
		"""
		Add new state to history and return majority vote.
		
		Args:
			state: Current state value (string, int, etc.)
		
		Returns:
			Most common state in history (majority vote)
		"""
		self._history.append(state)
		
		# Count occurrences
		counts = {}
		for s in self._history:
			counts[s] = counts.get(s, 0) + 1
		
		# Return majority
		return max(counts, key=counts.get)
	
	def get_history(self):
		"""Get history of states."""
		return list(self._history)
	
	def reset(self):
		"""Clear history."""
		self._history.clear()


class ExponentialSmoother:
	"""
	Apply exponential smoothing to reduce noise in numeric values.
	y_smooth = alpha * y_current + (1 - alpha) * y_prev
	"""
	
	def __init__(self, alpha=0.3):
		"""
		Initialize exponential smoother.
		
		Args:
			alpha: Smoothing factor in [0, 1]
				   Higher alpha = more weight on current value (less smoothing)
				   Lower alpha = more smoothing (more weight on history)
		"""
		self.alpha = float(alpha)
		self._prev_value = None
	
	def update(self, value):
		"""
		Apply exponential smoothing to value.
		
		Args:
			value: Current measurement (numeric)
		
		Returns:
			Smoothed value
		"""
		if self._prev_value is None:
			self._prev_value = value
			return value
		
		smoothed = self.alpha * value + (1 - self.alpha) * self._prev_value
		self._prev_value = smoothed
		return smoothed
	
	def reset(self):
		"""Reset smoother."""
		self._prev_value = None


class ConfirmationFilter:
	"""
	Confirm detection only if it appears for N consecutive frames.
	Prevents false positives from single-frame noise.
	"""
	
	def __init__(self, confidence_threshold=3):
		"""
		Initialize confirmation filter.
		
		Args:
			confidence_threshold: Number of consecutive frames to confirm
		"""
		self.confidence_threshold = int(confidence_threshold)
		self._counters = {}  # key -> frame count
	
	def update(self, key, detected):
		"""
		Update confirmation counter.
		
		Args:
			key: Unique identifier for the detection (e.g., track_id)
			detected: Boolean indicating if detected in current frame
		
		Returns:
			Boolean: True if detection is confirmed (reached threshold)
		"""
		if detected:
			if key not in self._counters:
				self._counters[key] = 0
			self._counters[key] += 1
		else:
			self._counters[key] = 0
		
		return self._counters.get(key, 0) >= self.confidence_threshold
	
	def reset(self, key):
		"""Reset counter for a key."""
		self._counters.pop(key, None)
	
	def get_count(self, key):
		"""Get current counter for a key."""
		return self._counters.get(key, 0)
