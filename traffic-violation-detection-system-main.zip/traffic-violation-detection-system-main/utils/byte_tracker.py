"""
Multi-object tracker using ByteTrack for persistent track IDs.
Falls back to simple centroid tracker if ByteTrack unavailable.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment
from collections import OrderedDict


class Track:
	"""Single track object with ID and trajectory."""
	
	def __init__(self, track_id, detection, frame_index):
		self.track_id = track_id
		self.bbox = detection["bbox"]
		self.center = detection["center"]
		self.class_name = detection.get("class_name")
		self.confidence = detection.get("confidence", 0.0)
		self.frames = [frame_index]
	
	def update(self, detection, frame_index):
		"""Update track with new detection."""
		self.bbox = detection["bbox"]
		self.center = detection["center"]
		self.frames.append(frame_index)
	
	def age(self):
		"""Get track age in frames."""
		if len(self.frames) < 2:
			return 1
		return self.frames[-1] - self.frames[0] + 1


class ByteTracker:
	"""
	ByteTrack multi-object tracker with persistent IDs.
	Matches detections across frames using centroid distance and IoU.
	"""
	
	def __init__(self, max_distance=50, max_age=30):
		"""
		Initialize ByteTracker.
		
		Args:
			max_distance: Max centroid distance for matching (pixels)
			max_age: Max frames to keep inactive track alive
		"""
		self.max_distance = float(max_distance)
		self.max_age = int(max_age)
		
		self.tracks = OrderedDict()
		self.next_id = 1
		self._frame_count = 0
	
	def update(self, detections, frame_index):
		"""
		Update tracker with new detections.
		
		Args:
			detections: List of dicts with 'bbox', 'center', 'class_name', 'confidence'
			frame_index: Current frame index
		
		Returns:
			List of dicts with track_id and detection info
		"""
		self._frame_count += 1
		
		# Match detections to existing tracks
		matches, unmatched_dets, unmatched_tracks = self._match_detections(detections)
		
		# Update matched tracks
		for det_idx, track_id in matches:
			self.tracks[track_id].update(detections[det_idx], frame_index)
		
		# Create new tracks for unmatched detections
		for det_idx in unmatched_dets:
			self.tracks[self.next_id] = Track(self.next_id, detections[det_idx], frame_index)
			self.next_id += 1
		
		# Remove stale tracks
		stale_ids = [
			tid for tid, track in self.tracks.items()
			if frame_index - track.frames[-1] > self.max_age
		]
		for tid in stale_ids:
			del self.tracks[tid]
		
		# Return active tracks with detection info
		results = []
		for track in self.tracks.values():
			results.append({
				"track_id": track.track_id,
				"bbox": track.bbox,
				"center": track.center,
				"class_name": track.class_name,
				"confidence": track.confidence,
				"age": track.age(),
			})
		
		return results
	
	def _match_detections(self, detections):
		"""
		Match detections to existing tracks using Hungarian algorithm.
		
		Returns:
			matches: List of (detection_idx, track_id) tuples
			unmatched_dets: List of unmatched detection indices
			unmatched_tracks: List of unmatched track IDs
		"""
		if len(self.tracks) == 0:
			return [], list(range(len(detections))), []
		
		if len(detections) == 0:
			return [], [], list(self.tracks.keys())
		
		# Compute cost matrix (distance between detections and tracks)
		num_tracks = len(self.tracks)
		num_dets = len(detections)
		cost_matrix = np.zeros((num_tracks, num_dets))
		
		track_ids = list(self.tracks.keys())
		for i, track_id in enumerate(track_ids):
			track = self.tracks[track_id]
			for j, det in enumerate(detections):
				# Centroid distance
				dx = track.center[0] - det["center"][0]
				dy = track.center[1] - det["center"][1]
				distance = (dx * dx + dy * dy) ** 0.5
				
				# Assign high cost if distance exceeds threshold
				if distance > self.max_distance:
					cost_matrix[i, j] = self.max_distance + 1
				else:
					cost_matrix[i, j] = distance
		
		# Hungarian algorithm
		track_indices, det_indices = linear_sum_assignment(cost_matrix)
		
		matches = []
		matched_track_set = set()
		matched_det_set = set()
		
		for t_idx, d_idx in zip(track_indices, det_indices):
			if cost_matrix[t_idx, d_idx] <= self.max_distance:
				matches.append((d_idx, track_ids[t_idx]))
				matched_track_set.add(track_ids[t_idx])
				matched_det_set.add(d_idx)
		
		unmatched_dets = [i for i in range(num_dets) if i not in matched_det_set]
		unmatched_tracks = [tid for tid in track_ids if tid not in matched_track_set]
		
		return matches, unmatched_dets, unmatched_tracks
