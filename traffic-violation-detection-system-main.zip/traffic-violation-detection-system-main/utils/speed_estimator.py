import math


class SpeedEstimator:
	def __init__(self, pixels_per_meter=8.0):
		self.pixels_per_meter = pixels_per_meter
		self._last_positions = {}

	def update(self, track_id, bbox, timestamp):
		x1, y1, x2, y2 = bbox
		center = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)
		last = self._last_positions.get(track_id)
		self._last_positions[track_id] = (center, timestamp)

		if last is None:
			return None

		last_center, last_ts = last
		delta_t = max(timestamp - last_ts, 1e-3)
		distance_px = math.hypot(center[0] - last_center[0], center[1] - last_center[1])
		distance_m = distance_px / self.pixels_per_meter
		speed_mps = distance_m / delta_t
		return round(speed_mps * 3.6, 2)
