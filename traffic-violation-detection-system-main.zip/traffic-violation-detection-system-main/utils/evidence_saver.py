import os
from datetime import datetime

try:
	import cv2
except ImportError:
	cv2 = None


class EvidenceSaver:
	"""Saves violation evidence images with timestamps and metadata."""

	def __init__(self, evidence_dir):
		self.evidence_dir = evidence_dir
		os.makedirs(evidence_dir, exist_ok=True)

	def save_violation(self, frame, track_id, violation_type, frame_index, plate_text=None):
		"""
		Save violation evidence image.
		
		Args:
			frame: Image array (BGR)
			track_id: Vehicle track ID
			violation_type: Type of violation (e.g., 'speeding', 'no_helmet')
			frame_index: Frame number
			plate_text: Optional license plate text
		
		Returns:
			str: Path to saved image, or None if save failed
		"""
		if cv2 is None:
			return None

		timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
		filename = f"{violation_type}_{track_id}_{timestamp}_{frame_index}.jpg"
		filepath = os.path.join(self.evidence_dir, filename)

		success = cv2.imwrite(filepath, frame)
		if success:
			return filepath
		return None
