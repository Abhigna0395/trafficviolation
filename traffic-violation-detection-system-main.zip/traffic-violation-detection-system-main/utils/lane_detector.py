try:
	import cv2
	import numpy as np
except ImportError:
	cv2 = None
	np = None


class LaneDetector:
	"""Detects road lanes using Canny edge detection and Hough line transform."""

	def __init__(self, roi_vertices=None, canny_threshold1=50, canny_threshold2=150):
		"""
		Initialize lane detector.
		
		Args:
			roi_vertices: Region of interest vertices [(x, y), ...] (optional, uses full frame if None)
			canny_threshold1: Lower Canny edge threshold
			canny_threshold2: Upper Canny edge threshold
		"""
		self.roi_vertices = roi_vertices
		self.canny_threshold1 = int(canny_threshold1)
		self.canny_threshold2 = int(canny_threshold2)
		self.hough_rho = 2
		self.hough_theta = np.pi / 180 if np is not None else None
		self.hough_threshold = 50
		self.hough_min_line_length = 50
		self.hough_max_line_gap = 10

	def detect(self, frame):
		"""
		Detect lane lines in frame.
		
		Args:
			frame: Image array (BGR or RGB)
		
		Returns:
			List of lines: [{"start": (x1, y1), "end": (x2, y2)}, ...]
		"""
		if cv2 is None or np is None:
			return []

		try:
			gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
			blurred = cv2.GaussianBlur(gray, (5, 5), 0)
			edges = cv2.Canny(blurred, self.canny_threshold1, self.canny_threshold2)

			if self.roi_vertices is not None:
				mask = np.zeros_like(edges)
				roi_pts = np.array([self.roi_vertices], dtype=np.int32)
				cv2.fillPoly(mask, roi_pts, 255)
				edges = cv2.bitwise_and(edges, mask)

			lines = cv2.HoughLinesP(
				edges,
				self.hough_rho,
				self.hough_theta,
				self.hough_threshold,
				minLineLength=self.hough_min_line_length,
				maxLineGap=self.hough_max_line_gap,
			)

			if lines is None:
				return []

			lane_lines = []
			for line in lines:
				x1, y1, x2, y2 = line[0]
				lane_lines.append({
					"start": (int(x1), int(y1)),
					"end": (int(x2), int(y2)),
				})

			return lane_lines

		except Exception as e:
			return []

	def draw_lanes(self, frame, lanes, color=(0, 255, 0), thickness=2):
		"""
		Draw detected lanes on frame.
		
		Args:
			frame: Image array (BGR)
			lanes: List of lane lines from detect()
			color: Line color (BGR tuple)
			thickness: Line thickness
		
		Returns:
			Modified frame with lanes drawn
		"""
		if cv2 is None:
			return frame

		frame_copy = frame.copy()
		for lane in lanes:
			pt1 = lane["start"]
			pt2 = lane["end"]
			cv2.line(frame_copy, pt1, pt2, color, thickness)

		return frame_copy
