"""
Geometry utilities for computer vision operations.
- IoU (Intersection over Union) computation
- Bounding box operations
- Point-in-polygon tests
- Line crossing detection
"""
import math


def iou(box1, box2):
	"""
	Compute Intersection over Union (IoU) between two axis-aligned bounding boxes.
	
	Args:
		box1: (x1, y1, x2, y2) - top-left and bottom-right corners
		box2: (x1, y1, x2, y2) - top-left and bottom-right corners
	
	Returns:
		IoU score in range [0, 1]
	"""
	x1_min, y1_min, x1_max, y1_max = box1
	x2_min, y2_min, x2_max, y2_max = box2
	
	# Compute intersection
	inter_x_min = max(x1_min, x2_min)
	inter_y_min = max(y1_min, y2_min)
	inter_x_max = min(x1_max, x2_max)
	inter_y_max = min(y1_max, y2_max)
	
	if inter_x_max < inter_x_min or inter_y_max < inter_y_min:
		return 0.0
	
	inter_area = (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)
	
	# Compute union
	box1_area = (x1_max - x1_min) * (y1_max - y1_min)
	box2_area = (x2_max - x2_min) * (y2_max - y2_min)
	union_area = box1_area + box2_area - inter_area
	
	if union_area == 0:
		return 0.0
	
	return inter_area / union_area


def bbox_area(bbox):
	"""Compute area of bounding box (x1, y1, x2, y2)."""
	x1, y1, x2, y2 = bbox
	return max(0, (x2 - x1) * (y2 - y1))


def bbox_intersection(box1, box2):
	"""Compute area of intersection between two bounding boxes."""
	x1_min, y1_min, x1_max, y1_max = box1
	x2_min, y2_min, x2_max, y2_max = box2
	
	inter_x_min = max(x1_min, x2_min)
	inter_y_min = max(y1_min, y2_min)
	inter_x_max = min(x1_max, x2_max)
	inter_y_max = min(y1_max, y2_max)
	
	if inter_x_max < inter_x_min or inter_y_max < inter_y_min:
		return 0
	
	return (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)


def extract_head_region(person_bbox, head_ratio=0.4):
	"""
	Extract upper portion of person bounding box as head region.
	
	Args:
		person_bbox: (x1, y1, x2, y2)
		head_ratio: fraction of height from top (default 0.4 = upper 40%)
	
	Returns:
		Head region bbox: (x1, y1, x2, y2)
	"""
	x1, y1, x2, y2 = person_bbox
	height = y2 - y1
	head_height = height * head_ratio
	
	return (x1, y1, x2, y1 + head_height)


def line_crossing_detection(prev_point, curr_point, line):
	"""
	Detect if a moving point crosses a line segment.
	Uses the sign change of the cross product.
	
	Args:
		prev_point: (x, y) - previous position
		curr_point: (x, y) - current position
		line: (x1, y1, x2, y2) - line segment endpoints
	
	Returns:
		True if point crossed line, False otherwise
	"""
	px_prev, py_prev = prev_point
	px_curr, py_curr = curr_point
	x1, y1, x2, y2 = line
	
	# Compute cross product sign for both positions
	def cross_product_sign(px, py):
		return math.copysign(1.0, (x2 - x1) * (py - y1) - (y2 - y1) * (px - x1))
	
	prev_side = cross_product_sign(px_prev, py_prev)
	curr_side = cross_product_sign(px_curr, py_curr)
	
	# Crossed if sides differ
	return prev_side != curr_side


def point_to_line_distance(point, line):
	"""
	Compute perpendicular distance from point to line.
	
	Args:
		point: (x, y)
		line: (x1, y1, x2, y2)
	
	Returns:
		Distance (float)
	"""
	px, py = point
	x1, y1, x2, y2 = line
	
	num = abs((y2 - y1) * px - (x2 - x1) * py + x2 * y1 - y2 * x1)
	denom = math.sqrt((y2 - y1) ** 2 + (x2 - x1) ** 2)
	
	if denom == 0:
		return 0
	
	return num / denom


def compute_motion_vector_angle(prev_point, curr_point):
	"""
	Compute angle of motion vector in degrees [-180, 180].
	
	Args:
		prev_point: (x, y)
		curr_point: (x, y)
	
	Returns:
		Angle in degrees
	"""
	dx = curr_point[0] - prev_point[0]
	dy = curr_point[1] - prev_point[1]
	
	angle_rad = math.atan2(dy, dx)
	angle_deg = math.degrees(angle_rad)
	
	return angle_deg


def angle_difference(angle1, angle2):
	"""
	Compute shortest angle difference in degrees [-180, 180].
	
	Args:
		angle1, angle2: Angles in degrees
	
	Returns:
		Angle difference in [-180, 180]
	"""
	diff = angle1 - angle2
	while diff > 180:
		diff -= 360
	while diff < -180:
		diff += 360
	return diff
