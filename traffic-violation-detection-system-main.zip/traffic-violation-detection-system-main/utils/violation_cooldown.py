"""
Violation cooldown manager to prevent duplicate entries.
Maintains per-vehicle cooldown timers for each violation type.
"""
import time


class ViolationCooldown:
	"""
	Manage violation cooldown to prevent duplicate logging.
	Each vehicle gets a cooldown timer per violation type.
	"""
	
	def __init__(self, cooldown_duration=5.0):
		"""
		Initialize violation cooldown manager.
		
		Args:
			cooldown_duration: Seconds between duplicate violation logging (default 5.0)
		"""
		self.cooldown_duration = float(cooldown_duration)
		self._violations = {}  # (track_id, violation_type) -> timestamp
	
	def can_log(self, track_id, violation_type, current_time):
		"""
		Check if violation can be logged (cooldown expired).
		
		Args:
			track_id: Vehicle track ID
			violation_type: Type of violation (e.g., "speeding", "red_light")
			current_time: Current timestamp
		
		Returns:
			Boolean: True if cooldown expired and violation can be logged
		"""
		key = (track_id, violation_type)
		last_logged = self._violations.get(key)
		
		if last_logged is None:
			return True
		
		elapsed = current_time - last_logged
		return elapsed >= self.cooldown_duration
	
	def log_violation(self, track_id, violation_type, current_time):
		"""
		Record violation timestamp.
		
		Args:
			track_id: Vehicle track ID
			violation_type: Type of violation
			current_time: Current timestamp
		"""
		key = (track_id, violation_type)
		self._violations[key] = current_time
	
	def reset_vehicle(self, track_id):
		"""Reset all cooldowns for a vehicle."""
		keys_to_remove = [k for k in self._violations if k[0] == track_id]
		for key in keys_to_remove:
			del self._violations[key]
	
	def cleanup_expired(self, current_time):
		"""Remove expired cooldowns (optimization)."""
		keys_to_remove = [
			k for k, ts in self._violations.items()
			if (current_time - ts) > self.cooldown_duration * 2
		]
		for k in keys_to_remove:
			del self._violations[k]
