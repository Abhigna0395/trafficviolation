"""
Production Annotator with Dashboard Panel and Clean Visualization.
Features: Clean bounding boxes, dashboard panel, FPS counter, traffic signal display, stop line.
"""
import time
try:
	import cv2
	import numpy as np
except ImportError:
	cv2 = None
	np = None


class ProductionAnnotator:
	"""Production-quality annotator with dashboard and clean visualization."""

	# Violation color mapping (BGR)
	COLORS = {
		"normal": (0, 200, 0),        # Green
		"no_helmet": (255, 0, 0),     # Blue
		"red_light": (128, 0, 128),   # Purple
		"wrong_way": (0, 0, 255),     # Red
	}

	# Traffic light colors (BGR)
	TRAFFIC_LIGHT_COLORS = {
		"red": (0, 0, 255),
		"yellow": (0, 165, 255),
		"green": (0, 255, 0),
	}

	def __init__(self, line_thickness=2):
		"""
		Initialize annotator.
		
		Args:
			line_thickness: Bounding box line thickness
		"""
		self.line_thickness = int(line_thickness)
		self._fps_samples = []
		self._last_time = None
		self._violation_counts = {
			"no_helmet": 0,
			"red_light": 0,
			"wrong_way": 0,
			"total": 0
		}

	def annotate_frame(
		self, 
		frame, 
		detections, 
		traffic_light_state="unknown",
		stop_line=None,
		fps=None
	):
		"""
		Annotate frame with all visualizations.
		
		Args:
			frame: Input frame (modified in-place)
			detections: List of detection dicts with track_id, bbox, violations
			traffic_light_state: Current traffic light state
			stop_line: Stop line coordinates (x1, y1, x2, y2)
			fps: Pre-computed FPS
		
		Returns:
			Annotated frame
		"""
		if cv2 is None:
			return frame

		# Draw minimal traffic signal indicator
		self._draw_traffic_signal(frame, traffic_light_state)
		
		# Draw minimal FPS counter
		if fps is not None:
			self._draw_fps(frame, fps)
		
		# Draw stop line
		if stop_line:
			self._draw_stop_line(frame, stop_line)
		
		# Draw detections
		for detection in detections:
			self._draw_detection(frame, detection)
		
		return frame

	def _draw_traffic_signal(self, frame, state):
		"""Draw minimal traffic signal state in top-left corner."""
		if cv2 is None or state == "unknown":
			return
		
		state_lower = state.lower()
		color = self.TRAFFIC_LIGHT_COLORS.get(state_lower, (200, 200, 200))
		
		x, y = 12, 22
		text = f"Signal: {state.upper()}"
		cv2.putText(frame, text, (x + 1, y + 1), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
		cv2.putText(frame, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)

	def _draw_fps(self, frame, fps):
		"""Draw minimal FPS counter in top-right corner."""
		if cv2 is None:
			return
		
		height, width = frame.shape[:2]
		text = f"FPS: {fps:.1f}"
		text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0]
		x = width - text_size[0] - 12
		y = 22
		cv2.putText(frame, text, (x + 1, y + 1), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
		cv2.putText(frame, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)

	def _draw_stop_line(self, frame, line):
		"""Draw stop line on frame."""
		if cv2 is None or not line or len(line) != 4:
			return
		
		x1, y1, x2, y2 = map(int, line)
		
		cv2.line(frame, (x1, y1), (x2, y2), (255, 255, 255), 2)

	def _draw_detection(self, frame, detection):
		"""Draw single detection with minimal labels."""
		if cv2 is None:
			return
		
		x1, y1, x2, y2 = map(int, detection["bbox"])
		track_id = detection.get("track_id", "?")
		violations = detection.get("violations", [])
		
		# Determine color based on violation
		color = self._get_detection_color(violations)
		
		# Draw bounding box
		cv2.rectangle(frame, (x1, y1), (x2, y2), color, self.line_thickness)
		
		font = cv2.FONT_HERSHEY_SIMPLEX
		font_scale = 0.5
		text_thickness = 1
		padding = 2

		id_text = f"ID:{track_id}"
		id_size = cv2.getTextSize(id_text, font, font_scale, text_thickness)[0]
		id_x = x1
		id_y = y1 - padding
		id_above = True
		if id_y - id_size[1] < 0:
			id_y = y2 + id_size[1] + padding
			id_above = False
		cv2.putText(frame, id_text, (id_x, id_y), font, font_scale, color, text_thickness, cv2.LINE_AA)

		if violations:
			violation_type = violations[0].get("type", "unknown")
			violation_label = self._format_violation_label(violation_type)
			viol_text = violation_label
			viol_size = cv2.getTextSize(viol_text, font, font_scale, 2)[0]
			viol_x = x1
			if id_above:
				viol_y = y2 + viol_size[1] + padding
				if viol_y + padding > frame.shape[0]:
					viol_y = y1 - padding
			else:
				viol_y = y1 - padding
				if viol_y - viol_size[1] < 0:
					viol_y = y2 + viol_size[1] + padding
			cv2.putText(frame, viol_text, (viol_x, viol_y), font, font_scale, color, 2, cv2.LINE_AA)

	def _get_detection_color(self, violations):
		"""Get color based on violation priority."""
		if not violations:
			return self.COLORS["normal"]
		
		# Priority: red_light > wrong_way > no_helmet
		violation_types = [v.get("type") for v in violations]
		
		if "red_light" in violation_types:
			return self.COLORS["red_light"]
		if "wrong_way" in violation_types:
			return self.COLORS["wrong_way"]
		if "no_helmet" in violation_types:
			return self.COLORS["no_helmet"]
		
		return self.COLORS["normal"]

	def _format_violation_label(self, violation_type):
		"""Format violation type for display."""
		labels = {
			"no_helmet": "No Helmet",
			"red_light": "Red Light Jump",
			"wrong_way": "Wrong Way"
		}
		return labels.get(violation_type, violation_type.replace("_", " ").title())

	def update_violation_count(self, violation_type):
		"""Update violation counter for dashboard panel."""
		if violation_type in ["no_helmet", "red_light", "wrong_way"]:
			self._violation_counts[violation_type] += 1
			self._violation_counts["total"] += 1

	def compute_fps(self, current_time=None):
		"""
		Compute moving average FPS.
		
		Args:
			current_time: Current timestamp
		
		Returns:
			Estimated FPS
		"""
		if current_time is None:
			current_time = time.time()
		
		if self._last_time is None:
			self._last_time = current_time
			return 0.0
		
		dt = current_time - self._last_time
		self._last_time = current_time
		
		if dt <= 0:
			return 0.0
		
		fps = 1.0 / dt
		self._fps_samples.append(fps)
		
		# Keep last 20 samples
		if len(self._fps_samples) > 20:
			self._fps_samples.pop(0)
		
		return sum(self._fps_samples) / len(self._fps_samples)
