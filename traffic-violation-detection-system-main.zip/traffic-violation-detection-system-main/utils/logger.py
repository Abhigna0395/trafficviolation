import logging
import sys
import os


class Logger:
	"""Centralized logging system for the application."""

	_instance = None

	def __new__(cls):
		if cls._instance is None:
			cls._instance = super(Logger, cls).__new__(cls)
			cls._instance._setup()
		return cls._instance

	def _setup(self):
		"""Setup logger with console and file handlers."""
		self.logger = logging.getLogger("TVD_System")
		self.logger.setLevel(logging.DEBUG)

		# Console handler
		console_handler = logging.StreamHandler(sys.stdout)
		console_handler.setLevel(logging.INFO)
		console_format = logging.Formatter(
			"[%(asctime)s] [%(levelname)s] %(message)s",
			datefmt="%Y-%m-%d %H:%M:%S"
		)
		console_handler.setFormatter(console_format)

		# File handler
		log_dir = "logs"
		os.makedirs(log_dir, exist_ok=True)
		file_handler = logging.FileHandler(os.path.join(log_dir, "tvd_system.log"))
		file_handler.setLevel(logging.DEBUG)
		file_format = logging.Formatter(
			"[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
			datefmt="%Y-%m-%d %H:%M:%S"
		)
		file_handler.setFormatter(file_format)

		self.logger.addHandler(console_handler)
		self.logger.addHandler(file_handler)

	def info(self, msg):
		self.logger.info(msg)

	def warning(self, msg):
		self.logger.warning(msg)

	def error(self, msg):
		self.logger.error(msg)

	def debug(self, msg):
		self.logger.debug(msg)

	def critical(self, msg):
		self.logger.critical(msg)

	def get_logger(self):
		"""Return the underlying logger instance."""
		return self.logger

