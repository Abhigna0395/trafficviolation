"""
Production Smart Traffic Violation Detection System.
Integrates: Vehicle, Helmet, Traffic Light Detection + ByteTrack + Violation Detection + Lane Detection + Web Dashboard.
NO SPEED DETECTION.
"""
import os
import yaml
import time
import itertools
try:
	import torch
	import cv2
except ImportError:
	torch = None
	cv2 = None

from models.vehicle_detector import VehicleDetector
from models.helmet_detector import HelmetDetector
from models.traffic_light_detector import TrafficLightDetector
from models.violation_detector_production import ProductionViolationDetector
from models.lane_detector import LaneDetector
from utils.byte_tracker import ByteTracker
from utils.production_annotator import ProductionAnnotator
from utils.video_processor import VideoProcessor
from utils.database import ViolationDatabase
from utils.evidence_saver import EvidenceSaver
from utils.logger import Logger
from utils.temporal_filter import ConfirmationFilter
from utils.violation_cooldown import ViolationCooldown
from utils.geometry import extract_head_region, iou
from utils.video_evidence import VideoEvidenceSaver


def auto_detect_device(logger):
	"""Auto-detect GPU availability."""
	if torch and torch.cuda.is_available():
		device = "0"
		logger.info(f"GPU detected: {torch.cuda.get_device_name(0)}")
	else:
		device = "cpu"
		logger.info("GPU not available, using CPU")
	return device


def load_config(config_path='config/config.yaml'):
	"""Load configuration from YAML."""
	with open(config_path, 'r', encoding='utf-8') as f:
		return yaml.safe_load(f)


def run_production_pipeline(config, logger=None):
	"""
	Run production Smart Traffic Violation Detection System.
	
	Features:
	- Vehicle Detection (YOLOv8)
	- Helmet Detection (IoU-based)
	- Traffic Light Detection (temporal smoothing)
	- Red Light Jump Detection (3-frame confirmation)
	- Wrong Way Detection (motion vectors)
	- Lane Detection (Canny + Hough)
	- ByteTrack (persistent tracking)
	- Web Dashboard (Flask + SQLite)
	"""
	
	if logger is None:
		logger = Logger().get_logger()
	
	# Extract config
	paths = config.get('paths', {})
	models_cfg = config.get('models', {})
	detectors_cfg = config.get('detectors', {})
	violation_cfg = config.get('violation', {})
	processing = config.get('processing', {})
	
	# Setup paths
	output_dir = paths.get('output_dir', 'outputs')
	evidence_dir = paths.get('evidence_dir', 'outputs/violations')
	os.makedirs(output_dir, exist_ok=True)
	os.makedirs(evidence_dir, exist_ok=True)
	
	logger.info("=" * 70)
	logger.info("SMART TRAFFIC VIOLATION DETECTION SYSTEM - PRODUCTION")
	logger.info("=" * 70)
	
	# Auto-detect device
	device = auto_detect_device(logger)
	
	logger.info("Initializing detectors and trackers...")
	
	# Load detectors
	vehicle_detector = VehicleDetector(
		model_path=models_cfg.get('vehicle_model'),
		confidence_threshold=detectors_cfg.get('vehicle_confidence', 0.5),
		device=device,
		class_names=detectors_cfg.get('vehicle_classes'),
	)
	
	helmet_detector = HelmetDetector(
		model_path=models_cfg.get('helmet_model'),
		confidence_threshold=detectors_cfg.get('helmet_confidence', 0.5),
		device=device,
	)
	
	traffic_light_detector = TrafficLightDetector(
		model_path=models_cfg.get('traffic_light_model'),
		confidence_threshold=detectors_cfg.get('traffic_light_confidence', 0.5),
		device=device,
	)
	
	# Initialize ByteTrack
	tracker = ByteTracker(
		max_distance=processing.get('max_track_distance', 50),
		max_age=processing.get('max_track_missed', 30),
	)
	
	# Initialize violation detector (NO SPEED)
	violation_detector = ProductionViolationDetector(
		red_light=violation_cfg.get('red_light', {}),
		wrong_way=violation_cfg.get('wrong_way', {}),
		red_light_confirmation_frames=violation_cfg.get('red_light', {}).get('confirmation_frames', 3),
		wrong_way_smoothing_frames=violation_cfg.get('wrong_way', {}).get('smoothing_frames', 5),
		violation_cooldown_s=violation_cfg.get('violation_cooldown_s', 5.0),
	)
	
	# Initialize lane detector
	lane_detector = LaneDetector(
		canny_low=50,
		canny_high=150,
		hough_threshold=50,
		min_line_length=100,
		max_line_gap=50,
		overlay_alpha=0.7,
	)
	
	# Initialize annotator
	annotator = ProductionAnnotator(line_thickness=2)

	# Helmet violation confirmation + cooldown
	helmet_confirmation = ConfirmationFilter(3)
	helmet_cooldown = ViolationCooldown(violation_cfg.get('violation_cooldown_s', 5.0))
	
	# Initialize database and evidence saver
	database = ViolationDatabase(paths.get('db_path', 'data/violations.db'))
	evidence_saver = EvidenceSaver(evidence_dir)
	video_evidence_saver = VideoEvidenceSaver(evidence_dir, fps=output_fps, duration_before_s=5, duration_after_s=5)
	
	# Video processing
	processor = VideoProcessor(
		paths.get('input_video', 'data/sample.mp4'),
		max_frames=processing.get('max_frames'),  # None = full video
		frame_skip=processing.get('frame_skip', 1),
	)
	
	output_video_path = os.path.join(output_dir, 'annotated_video.mp4')
	output_fps = processing.get('output_fps', 30)
	
	logger.info("Starting pipeline...")
	logger.info("=" * 70)
	
	# Get stop line from config
	stop_line = violation_cfg.get('red_light', {}).get('line')
	
	# Initialize video writer
	frame_iter = processor.iter_frames()
	try:
		frame_index, frame, timestamp = next(frame_iter)
	except StopIteration:
		logger.error("Failed to read first frame")
		return
	
	height, width = frame.shape[:2]
	if cv2:
		fourcc = cv2.VideoWriter_fourcc(*'mp4v')
		video_writer = cv2.VideoWriter(output_video_path, fourcc, output_fps, (width, height))
	else:
		video_writer = None
	
	start_time = time.time()
	
	for frame_index, frame, timestamp in itertools.chain([(frame_index, frame, timestamp)], frame_iter):
		frame_start = time.time()
		
		# 1. Detect lanes (for visualization)
		lanes = lane_detector.detect_lanes(frame)
		lane_detector.draw_lanes(frame, lanes)
		
		# 2. Detect vehicles
		vehicle_detections = vehicle_detector.detect(frame)
		
		# Compute centers for ByteTrack
		for detection in vehicle_detections:
			bbox = detection.get('bbox')
			if bbox:
				x1, y1, x2, y2 = bbox
				detection['center'] = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)
		
		# 3. Track vehicles with ByteTrack
		tracked_detections = tracker.update(vehicle_detections, frame_index)
		
		# 4. Detect helmets (for motorcycles)
		try:
			helmet_results = helmet_detector.detect(frame)
			people_boxes = vehicle_detector.detect_people(frame)
		except Exception as e:
			logger.warning(f"Helmet detection failed: {e}")
			helmet_results = []
			people_boxes = []

		for detection in tracked_detections:
			class_name = detection.get('class_name', '')
			if class_name != 'motorcycle':
				continue

			bbox = detection.get('bbox')
			track_id = detection.get('track_id')
			if not bbox or track_id is None:
				continue

			rider_boxes = []
			for person_bbox in people_boxes:
				px1, py1, px2, py2 = person_bbox
				cx = (px1 + px2) / 2.0
				cy = (py1 + py2) / 2.0
				if bbox[0] <= cx <= bbox[2] and bbox[1] <= cy <= bbox[3]:
					rider_boxes.append(person_bbox)

			if not rider_boxes:
				rider_boxes = [bbox]

			has_helmet = False
			for rider_box in rider_boxes:
				head_box = extract_head_region(rider_box, head_ratio=0.4)
				for helmet_box in helmet_results:
					iou_score = iou(head_box, helmet_box)
					hx1, hy1, hx2, hy2 = helmet_box
					hx = (hx1 + hx2) / 2.0
					hy = (hy1 + hy2) / 2.0
					if iou_score >= 0.2 or (head_box[0] <= hx <= head_box[2] and head_box[1] <= hy <= head_box[3]):
						has_helmet = True
						break
				if has_helmet:
					break

			if has_helmet:
				helmet_confirmation.reset(track_id)
				continue

			confirmed = helmet_confirmation.update(track_id, True)
			if not confirmed:
				continue

			if not helmet_cooldown.can_log(track_id, 'no_helmet', timestamp):
				continue

			detection.setdefault('violations', []).append({
				'type': 'no_helmet',
				'detail': 'person on motorcycle without helmet (confirmed)',
				'severity': 'medium'
			})
			helmet_cooldown.log_violation(track_id, 'no_helmet', timestamp)
		
		# 5. Detect traffic lights with temporal smoothing
		traffic_light_state = "unknown"
		try:
			traffic_lights = traffic_light_detector.detect(frame)
			if traffic_lights:
				traffic_light_state = traffic_lights[0].get('state', 'unknown')
				violation_detector.set_traffic_light_state(traffic_light_state)
		except Exception as e:
			logger.warning(f"Traffic light detection failed: {e}")
		
		# 6. Check violations (red light jump, wrong way)
		output_detections = []
		for detection in tracked_detections:
			track_id = detection.get('track_id')
			center = detection.get('center')
			
			# Check violations
			violations = violation_detector.update(track_id, center, timestamp, frame_index)
			
			# Merge with existing violations (e.g., helmet)
			existing_violations = detection.get('violations', [])
			for v in violations:
				if not any(ev.get('type') == v.get('type') for ev in existing_violations):
					existing_violations.append(v)
			
			# Update detection with combined violations
			detection['violations'] = existing_violations
			
			# Update violation counts for dashboard
			for v in violations:
				annotator.update_violation_count(v['type'])
				
				# Save evidence video clip
				violation_key = f"{track_id}_{frame_index}"
				clip_path = video_evidence_saver.save_violation_clip(
					violation_key,
					v['type'],
					frame,
				)
				
				# Log to database
				database.insert_violation(
					track_id=track_id,
					plate_number=detection.get('plate_number'),
					violation_type=v['type'],
					speed_kmh=None,
					frame_index=frame_index,
					vehicle_class=detection.get('class_name'),
					violation_detail=v.get('detail'),
					bbox=detection.get('bbox'),
					location="Main St",
					image_path=clip_path,
				)
				
				logger.warning(f"[VIOLATION] Frame {frame_index}: {v['type'].upper()} | Track {track_id} | {v['detail']}")
				if clip_path:
					logger.info(f"  Evidence clip saved: {clip_path}")
			
			# Add current frame to buffer for next violation
			video_evidence_saver.add_frame(frame)
			output_detections.append(detection)
		
		# 7. Compute FPS
		fps = annotator.compute_fps(time.time())
		
		# 8. Annotate frame
		annotator.annotate_frame(
			frame,
			output_detections,
			traffic_light_state=traffic_light_state,
			stop_line=stop_line,
			fps=fps
		)
		
		# 9. Write frame to output video
		if video_writer:
			video_writer.write(frame)
		
		# Progress logging
		if frame_index % 30 == 0:
			logger.info(f"Processing frame {frame_index}... ({fps:.1f} FPS)")
		
		# Next frame handled by iterator
	
	# Cleanup
	if video_writer:
		video_writer.release()
	
	end_time = time.time()
	elapsed = end_time - start_time
	
	logger.info("=" * 70)
	logger.info("Pipeline complete!")
	logger.info(f"  Frames processed: {frame_index}")
	logger.info(f"  Violations detected: {annotator._violation_counts['total']}")
	logger.info(f"    - No Helmet: {annotator._violation_counts['no_helmet']}")
	logger.info(f"    - Red Light: {annotator._violation_counts['red_light']}")
	logger.info(f"    - Wrong Way: {annotator._violation_counts['wrong_way']}")
	logger.info(f"  Elapsed time: {elapsed:.2f}s")
	logger.info(f"  Average FPS: {frame_index / elapsed:.1f}")
	logger.info(f"  Output video: {output_video_path}")
	logger.info("=" * 70)
	logger.info("Start web dashboard: python dashboard_server.py")
	logger.info("=" * 70)


if __name__ == '__main__':
	config = load_config()
	logger = Logger().get_logger()
	run_production_pipeline(config, logger)
