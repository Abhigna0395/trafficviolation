import os
import sqlite3
from pathlib import Path

import yaml
from flask import Flask, jsonify, render_template, send_file, send_from_directory


BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config" / "config.yaml"


def _load_config():
    if not CONFIG_PATH.exists():
        return {}
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _db_path_from_config(cfg):
    db_path = cfg.get("paths", {}).get("db_path", "data/violations.db")
    return (BASE_DIR / db_path).resolve()


def _evidence_dirs_from_config(cfg):
    paths = cfg.get("paths", {})
    candidates = [
        paths.get("evidence_dir", "outputs/violations"),
        "outputs/evidence",
        "outputs/violations",
    ]
    deduped = []
    for item in candidates:
        p = str((BASE_DIR / item).resolve())
        if p not in deduped:
            deduped.append(p)
    return [Path(p) for p in deduped]


def _pick_output_video():
    candidates = [
        BASE_DIR / "outputs" / "annotated_video.mp4",
        BASE_DIR / "outputs" / "output.mp4",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _safe_row_dict(cursor, row):
    return {description[0]: row[idx] for idx, description in enumerate(cursor.description)}


def _bbox_to_center(bbox_text):
    if not bbox_text:
        return None
    try:
        vals = [float(part) for part in str(bbox_text).split(",")]
        if len(vals) != 4:
            return None
        x1, y1, x2, y2 = vals
        return {"x": (x1 + x2) / 2.0, "y": (y1 + y2) / 2.0}
    except Exception:
        return None


def _vehicle_stats(rows):
    total = max(len(rows), 1)
    counts = {
        "car": 0,
        "bike": 0,
        "auto": 0,
        "bus": 0,
    }
    for row in rows:
        name = (row.get("vehicle_class") or "").lower()
        if name in {"motorcycle", "motorbike", "bike", "two_wheeler", "two-wheeler"}:
            counts["bike"] += 1
        elif "car" in name:
            counts["car"] += 1
        elif name in {"auto", "rickshaw", "autorickshaw"}:
            counts["auto"] += 1
        elif "bus" in name:
            counts["bus"] += 1
    return {key: round((value / total) * 100, 2) for key, value in counts.items()}


def _stats_counts(rows):
    out = {
        "total": len(rows),
        "no_helmet": 0,
        "red_light": 0,
        "wrong_way": 0,
        "lane_change": 0,
    }
    for row in rows:
        vtype = (row.get("violation_type") or "").lower()
        if vtype in out:
            out[vtype] += 1
    return out


def create_app():
    app = Flask(__name__, template_folder="templates")

    @app.after_request
    def add_no_cache_headers(response):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

    @app.route("/")
    def dashboard():
        return render_template("dashboard.html")

    @app.route("/api/stats")
    def api_stats():
        cfg = _load_config()
        db_path = _db_path_from_config(cfg)

        if not db_path.exists():
            return jsonify(
                {
                    "success": True,
                    "stats": {
                        "total": 0,
                        "no_helmet": 0,
                        "red_light": 0,
                        "wrong_way": 0,
                        "lane_change": 0,
                    },
                    "vehicle_stats": {"car": 0, "bike": 0, "auto": 0, "bus": 0},
                    "recent_violations": [],
                    "latest_violation": None,
                    "heatmap_points": [],
                }
            )

        with sqlite3.connect(str(db_path)) as conn:
            conn.row_factory = lambda cursor, row: _safe_row_dict(cursor, row)
            all_rows = conn.execute(
                "SELECT id, timestamp, track_id, plate_number, vehicle_class, violation_type, image_path, bbox FROM violations ORDER BY id DESC"
            ).fetchall()

        heatmap_points = []
        for row in all_rows[:300]:
            center = _bbox_to_center(row.get("bbox"))
            if center:
                heatmap_points.append(center)

        recent_rows = all_rows[:25]
        latest = all_rows[0] if all_rows else None

        return jsonify(
            {
                "success": True,
                "stats": _stats_counts(all_rows),
                "vehicle_stats": _vehicle_stats(all_rows),
                "recent_violations": recent_rows,
                "latest_violation": latest,
                "heatmap_points": heatmap_points,
            }
        )

    @app.route("/output-video")
    def output_video():
        video_path = _pick_output_video()
        if video_path is None:
            return jsonify({"success": False, "error": "No output video found"}), 404
        return send_file(str(video_path), mimetype="video/mp4")

    @app.route("/evidence/<path:filename>")
    def evidence_file(filename):
        cfg = _load_config()
        for evidence_dir in _evidence_dirs_from_config(cfg):
            candidate = evidence_dir / filename
            if candidate.exists() and candidate.is_file():
                return send_from_directory(str(evidence_dir), filename)
        return jsonify({"success": False, "error": "Evidence file not found"}), 404

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=False)
