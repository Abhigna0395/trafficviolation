import csv
import math
import shutil
from pathlib import Path

import cv2
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
ASSETS_DIR = ROOT / "paper_assets"
FIG_DIR = ASSETS_DIR / "figures"
TABLE_DIR = ASSETS_DIR / "tables"


def ensure_dirs():
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    (FIG_DIR / "model_plots").mkdir(parents=True, exist_ok=True)
    (FIG_DIR / "app_frames").mkdir(parents=True, exist_ok=True)
    (FIG_DIR / "evidence_samples").mkdir(parents=True, exist_ok=True)


def copy_if_exists(src: Path, dst: Path):
    if src.exists():
        shutil.copy2(src, dst)


def copy_model_figures(run_name: str):
    run_dir = ROOT / run_name
    names = [
        "results.png",
        "confusion_matrix.png",
        "confusion_matrix_normalized.png",
        "BoxP_curve.png",
        "BoxR_curve.png",
        "BoxF1_curve.png",
        "BoxPR_curve.png",
    ]
    for name in names:
        src = run_dir / name
        dst = FIG_DIR / "model_plots" / f"{run_name}_{name}"
        copy_if_exists(src, dst)


def parse_results_csv(path: Path):
    rows = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows


def to_float(row, key, default=0.0):
    val = row.get(key)
    try:
        return float(val)
    except Exception:
        return default


def build_metrics_table(run_rows_map):
    metrics = []
    for run_name, rows in run_rows_map.items():
        if not rows:
            continue
        last = rows[-1]
        p = to_float(last, "metrics/precision(B)")
        r = to_float(last, "metrics/recall(B)")
        m50 = to_float(last, "metrics/mAP50(B)")
        m5095 = to_float(last, "metrics/mAP50-95(B)")
        f1 = (2 * p * r / (p + r)) if (p + r) > 0 else 0.0
        metrics.append(
            {
                "run": run_name,
                "precision": p,
                "recall": r,
                "f1": f1,
                "mAP50": m50,
                "mAP50-95": m5095,
            }
        )
    return metrics


def save_metrics_csv(metrics):
    out_csv = TABLE_DIR / "model_metrics_comparison.csv"
    with out_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["run", "precision", "recall", "f1", "mAP50", "mAP50-95"])
        for m in metrics:
            writer.writerow(
                [
                    m["run"],
                    f"{m['precision']:.6f}",
                    f"{m['recall']:.6f}",
                    f"{m['f1']:.6f}",
                    f"{m['mAP50']:.6f}",
                    f"{m['mAP50-95']:.6f}",
                ]
            )


def plot_metrics_bar(metrics):
    if not metrics:
        return
    keys = ["precision", "recall", "f1", "mAP50", "mAP50-95"]
    labels = ["Precision", "Recall", "F1", "mAP@50", "mAP@50-95"]
    runs = [m["run"] for m in metrics]

    x = list(range(len(labels)))
    width = 0.36

    fig, ax = plt.subplots(figsize=(10, 5.5), dpi=160)
    for i, m in enumerate(metrics):
        offsets = [xi + (i - (len(metrics) - 1) / 2) * width for xi in x]
        vals = [m[k] for k in keys]
        ax.bar(offsets, vals, width=width, label=m["run"])

    ax.set_ylim(0, 1.05)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Score")
    ax.set_title("Model Performance Comparison")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(title="Run")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "comparison_metrics_bar.png")
    plt.close(fig)


def plot_map_curves(run_rows_map):
    fig, ax = plt.subplots(figsize=(9, 5), dpi=160)
    plotted = False
    for run_name, rows in run_rows_map.items():
        if not rows:
            continue
        epochs = []
        m50s = []
        for row in rows:
            epochs.append(int(float(row.get("epoch", 0))))
            m50s.append(to_float(row, "metrics/mAP50(B)"))
        if epochs:
            plotted = True
            ax.plot(epochs, m50s, linewidth=2.0, label=f"{run_name} mAP@50")
    if plotted:
        ax.set_xlabel("Epoch")
        ax.set_ylabel("mAP@50")
        ax.set_ylim(0, 1.05)
        ax.set_title("mAP@50 vs Epoch")
        ax.grid(alpha=0.25)
        ax.legend()
        fig.tight_layout()
        fig.savefig(FIG_DIR / "comparison_map50_curve.png")
    plt.close(fig)


def load_violation_rows():
    candidates = [
        ROOT / "outputs" / "output_violations.csv",
        ROOT / "outputs" / "lane_violations.csv",
        ROOT / "outputs" / "violations_report.csv",
    ]
    for path in candidates:
        if path.exists():
            with path.open("r", encoding="utf-8", newline="") as f:
                return list(csv.DictReader(f)), path.name
    return [], None


def plot_violation_distribution(rows):
    if not rows:
        return
    counts = {}
    for row in rows:
        v = (row.get("ViolationType") or row.get("violation_type") or "UNKNOWN").strip().upper()
        counts[v] = counts.get(v, 0) + 1

    labels = list(counts.keys())
    values = [counts[k] for k in labels]

    fig, ax = plt.subplots(figsize=(8, 5), dpi=160)
    ax.bar(labels, values)
    ax.set_title("Violation Type Distribution")
    ax.set_xlabel("Violation Type")
    ax.set_ylabel("Count")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "application_violation_distribution.png")
    plt.close(fig)


def extract_video_frames():
    candidates = [
        ROOT / "outputs" / "output.mp4",
        ROOT / "outputs" / "annotated_video.mp4",
        ROOT / "outputs" / "annotated.mp4",
    ]
    video_path = None
    for c in candidates:
        if c.exists():
            video_path = c
            break
    if video_path is None:
        return

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if frame_count <= 0:
        cap.release()
        return

    picks = [max(0, int(frame_count * r) - 1) for r in (0.2, 0.5, 0.8)]
    saved = []
    for idx, frame_no in enumerate(picks, start=1):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_no)
        ok, frame = cap.read()
        if not ok:
            continue
        out = FIG_DIR / "app_frames" / f"output_frame_{idx}.jpg"
        cv2.imwrite(str(out), frame)
        saved.append(out)
    cap.release()

    if saved:
        imgs = [cv2.imread(str(p)) for p in saved]
        imgs = [im for im in imgs if im is not None]
        if imgs:
            h = min(im.shape[0] for im in imgs)
            resized = [cv2.resize(im, (int(im.shape[1] * h / im.shape[0]), h)) for im in imgs]
            montage = cv2.hconcat(resized)
            cv2.imwrite(str(FIG_DIR / "app_frames_montage.jpg"), montage)


def copy_evidence_samples(limit=8):
    src_dir = ROOT / "outputs" / "violations"
    if not src_dir.exists():
        return
    files = sorted([p for p in src_dir.iterdir() if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png"}])
    for p in files[:limit]:
        shutil.copy2(p, FIG_DIR / "evidence_samples" / p.name)


def write_manifest(metrics, violation_csv_name):
    md = ASSETS_DIR / "README.md"
    runs_used = ", ".join(m["run"] for m in metrics) if metrics else "None"
    lines = [
        "# IEEE Paper Assets",
        "",
        "This folder contains publication-ready figures and tables generated from model training runs and application outputs.",
        "",
        "## Purpose",
        "Use these assets directly in reports/papers (for example, IEEE format) to summarize model performance and real-world violation detection behavior.",
        "",
        "## Regeneration",
        "Run the command below from the project root to refresh all figures and tables:",
        "",
        "```bash",
        "python scripts/generate_ieee_assets.py",
        "```",
        "",
        "The script is idempotent and safely overwrites generated files with updated values.",
        "",
        "## Key Figures",
        "- `figures/comparison_metrics_bar.png`: Precision, Recall, F1, mAP comparison across runs.",
        "- `figures/comparison_map50_curve.png`: mAP@50 vs epoch comparison.",
        "- `figures/application_violation_distribution.png`: Violation-type frequency from output CSV.",
        "- `figures/app_frames_montage.jpg`: Sample annotated output frames.",
        "- `figures/model_plots/`: YOLO generated curves/confusion matrices copied from train runs.",
        "- `figures/evidence_samples/`: Example evidence snapshots.",
        "",
        "## Tables",
        "- `tables/model_metrics_comparison.csv`: Final Precision/Recall/F1/mAP summary for each run.",
        "",
        "## Folder Layout",
        "```text",
        "paper_assets/",
        "  figures/",
        "    app_frames/",
        "    evidence_samples/",
        "    model_plots/",
        "    comparison_metrics_bar.png",
        "    comparison_map50_curve.png",
        "    application_violation_distribution.png",
        "    app_frames_montage.jpg",
        "  tables/",
        "    model_metrics_comparison.csv",
        "```",
        "",
        "## Data Sources",
        f"- Train runs used: {runs_used}",
        f"- Violation CSV used: {violation_csv_name or 'None found'}",
        "- Optional video source: first available from `outputs/output.mp4`, `outputs/annotated_video.mp4`, or `outputs/annotated.mp4`.",
        "- Evidence source: images from `outputs/violations/` (up to 8 copied).",
        "",
        "## Notes",
        "- Missing optional sources are skipped gracefully (for example, no video means no extracted app frames).",
        "- To compare additional train runs, extend `run_rows_map` in `scripts/generate_ieee_assets.py`.",
        "",
    ]
    md.write_text("\n".join(lines), encoding="utf-8")


def main():
    ensure_dirs()

    run_rows_map = {
        "train6": parse_results_csv(ROOT / "train6" / "results.csv"),
        "train7": parse_results_csv(ROOT / "train7" / "results.csv"),
    }

    copy_model_figures("train6")
    copy_model_figures("train7")

    metrics = build_metrics_table(run_rows_map)
    save_metrics_csv(metrics)
    plot_metrics_bar(metrics)
    plot_map_curves(run_rows_map)

    rows, violation_csv_name = load_violation_rows()
    plot_violation_distribution(rows)

    extract_video_frames()
    copy_evidence_samples(limit=8)
    write_manifest(metrics, violation_csv_name)

    print("Generated IEEE assets at:", ASSETS_DIR)


if __name__ == "__main__":
    main()
