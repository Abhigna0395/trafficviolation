#!/usr/bin/env python
"""
Test VideoProcessor with no max_frames limit (process entire video).
This tests the refactored behavior where max_frames=None by default.
"""
from utils.video_processor import VideoProcessor
import time

print("=" * 60)
print("Testing VideoProcessor: Process Entire Video (No Limit)")
print("=" * 60)

# Create processor with max_frames=None (default)
processor = VideoProcessor('data/sample.mp4', max_frames=None, frame_skip=1)

print("\nIterating through all frames...")
start = time.time()
frame_count = 0

for frame_index, frame, timestamp in processor.iter_frames():
	frame_count += 1
	if frame_count % 50 == 0:
		print(f"  Processed {frame_count} frames...")

elapsed = time.time() - start
print(f"\nTotal frames processed: {frame_count}")
print(f"Processing time: {elapsed:.2f}s")
print("=" * 60)
