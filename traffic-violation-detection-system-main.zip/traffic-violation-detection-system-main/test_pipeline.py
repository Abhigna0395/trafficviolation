#!/usr/bin/env python
import os
import yaml
from main import run_pipeline

# Load test config
config_path = os.path.join("config", "config_test.yaml")
with open(config_path, "r", encoding="utf-8") as file:
	cfg = yaml.safe_load(file)

print("=" * 60)
print("Running Traffic Violation Detection Pipeline (Test Mode)")
print("=" * 60)
print(f"Config: max_frames={cfg['processing']['max_frames']}")
print("=" * 60)

run_pipeline(cfg)

print("=" * 60)
print("Test completed successfully!")
print("=" * 60)
