# Traffic Violation Detection System

Pretrained-only pipeline for vehicle detection, speed estimation, and violation logging.

## Real detectors (YOLO + OCR)
- Vehicle detector uses the Ultralytics YOLO model set in `detectors.vehicle_model`.
- License plate text is read directly from the vehicle crop using EasyOCR.

This setup uses pretrained models only. No custom datasets or training are required.

## Violation rules
Configure violation zones and rules in [config/config.yaml](config/config.yaml):
- `red_light.line` is a stop-line segment (x1, y1, x2, y2) in pixels.
- `wrong_way.direction` is the allowed motion vector for the lane.
- `illegal_parking.zones` is a list of rectangles [x1, y1, x2, y2].

## Setup
1) Install dependencies from [requirements.txt](requirements.txt)
2) Update input video path in [config/config.yaml](config/config.yaml)
3) Run: `python main.py`

## Notes
- Set detector backends in [config/config.yaml](config/config.yaml) to switch between mock and YOLO.
- Violations are logged to the sqlite database defined in config.
