"""
Lane Detection Module using Canny + Hough Transform.
Detects and visualizes traffic lanes with ROI masking.
"""
try:
	import cv2
	import numpy as np
except ImportError:
	cv2 = None
	np = None


class LaneDetector:
	"""Lane detection using Canny edge detection and Hough Transform."""

	def __init__(
		self,
		roi_vertices=None,
		canny_low=50,
		canny_high=150,
		hough_threshold=50,
		min_line_length=100,
		max_line_gap=50,
		overlay_alpha=0.7,
		min_slope=0.5,
		max_slope=5.0,
		lane_top_ratio=0.6,
		line_thickness=3,
	):
		"""
		Initialize lane detector.
		
		Args:
			roi_vertices: List of (x, y) tuples defining ROI polygon
			canny_low: Lower threshold for Canny edge detection
			canny_high: Upper threshold for Canny edge detection
			hough_threshold: Hough transform threshold
			min_line_length: Minimum line length in pixels
			max_line_gap: Maximum gap between lines
			overlay_alpha: Transparency factor for lane overlay (0-1)
		"""
		self.roi_vertices = roi_vertices
		self.canny_low = int(canny_low)
		self.canny_high = int(canny_high)
		self.hough_threshold = int(hough_threshold)
		self.min_line_length = int(min_line_length)
		self.max_line_gap = int(max_line_gap)
		self.overlay_alpha = float(overlay_alpha)
		self.min_slope = float(min_slope)
		self.max_slope = float(max_slope)
		self.lane_top_ratio = float(lane_top_ratio)
		self.line_thickness = int(line_thickness)

	def detect_lanes(self, frame):
		"""
		Detect lanes in frame.
		
		Args:
			frame: Input BGR image
		
		Returns:
			List of detected lines: [((x1, y1, x2, y2), slope), ...]
		"""
		if cv2 is None or np is None:
			return []

		# Convert to grayscale
		gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
		
		# Apply Gaussian blur
		blurred = cv2.GaussianBlur(gray, (5, 5), 0)
		
		# Canny edge detection
		edges = cv2.Canny(blurred, self.canny_low, self.canny_high)
		
		# Apply ROI mask
		masked_edges = self._apply_roi_mask(edges, frame.shape)
		
		# Hough Line Transform
		lines = cv2.HoughLinesP(
			masked_edges,
			rho=1,
			theta=np.pi / 180,
			threshold=self.hough_threshold,
			minLineLength=self.min_line_length,
			maxLineGap=self.max_line_gap,
		)
		
		if lines is None:
			return []
		
		# Process lines
		detected_lines = []
		for line in lines:
			x1, y1, x2, y2 = line[0]
			slope = self._calculate_slope(x1, y1, x2, y2)
			if slope is None:
				continue
			abs_slope = abs(slope)
			if abs_slope < self.min_slope or abs_slope > self.max_slope:
				continue
			detected_lines.append(((x1, y1, x2, y2), slope))
		
		return detected_lines

	def draw_lanes(self, frame, lines):
		"""
		Draw detected lanes on frame with transparency.
		
		Args:
			frame: Input frame (will be modified in-place)
			lines: List of detected lines from detect_lanes()
		
		Returns:
			Frame with lanes drawn
		"""
		if cv2 is None or np is None or not lines:
			return frame
		
		# Create overlay for lanes
		overlay = frame.copy()
		
		# Separate left and right lanes by slope
		left_lines = []
		right_lines = []
		
		for (x1, y1, x2, y2), slope in lines:
			if slope < 0:
				left_lines.append((x1, y1, x2, y2))
			else:
				right_lines.append((x1, y1, x2, y2))
		
		height = frame.shape[0]
		y_max = height
		y_min = int(height * self.lane_top_ratio)

		# Draw averaged lanes only
		left_avg = self._average_lane_line(left_lines, y_min, y_max)
		if left_avg:
			x1, y1, x2, y2 = left_avg
			cv2.line(overlay, (x1, y1), (x2, y2), (0, 255, 255), self.line_thickness)
		right_avg = self._average_lane_line(right_lines, y_min, y_max)
		if right_avg:
			x1, y1, x2, y2 = right_avg
			cv2.line(overlay, (x1, y1), (x2, y2), (0, 255, 255), self.line_thickness)
		
		# Blend with original frame
		cv2.addWeighted(overlay, self.overlay_alpha, frame, 1 - self.overlay_alpha, 0, frame)
		
		return frame

	def _apply_roi_mask(self, image, shape):
		"""Apply region of interest mask."""
		if self.roi_vertices is None:
			# Default ROI: bottom half trapezoid
			height, width = shape[:2]
			vertices = np.array([[
				(0, height),
				(width // 4, height // 2),
				(3 * width // 4, height // 2),
				(width, height)
			]], dtype=np.int32)
		else:
			vertices = np.array([self.roi_vertices], dtype=np.int32)
		
		mask = np.zeros_like(image)
		cv2.fillPoly(mask, vertices, 255)
		masked_image = cv2.bitwise_and(image, mask)
		
		return masked_image

	def _calculate_slope(self, x1, y1, x2, y2):
		"""Calculate line slope, handling vertical lines."""
		if x2 - x1 == 0:
			return None
		return (y2 - y1) / (x2 - x1)

	def _average_lane_line(self, lines, y_min, y_max):
		"""Average multiple line segments into a single lane line."""
		if not lines:
			return None

		slopes = []
		intercepts = []
		weights = []
		for x1, y1, x2, y2 in lines:
			slope = self._calculate_slope(x1, y1, x2, y2)
			if slope is None:
				continue
			if abs(slope) < 1e-6:
				continue
			intercept = y1 - slope * x1
			length = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
			slopes.append(slope)
			intercepts.append(intercept)
			weights.append(length)

		if not slopes:
			return None

		avg_slope = float(np.average(slopes, weights=weights))
		avg_intercept = float(np.average(intercepts, weights=weights))

		x_min = int((y_min - avg_intercept) / avg_slope)
		x_max = int((y_max - avg_intercept) / avg_slope)
		return (x_min, y_min, x_max, y_max)
