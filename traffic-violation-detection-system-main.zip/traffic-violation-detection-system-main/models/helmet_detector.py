try:
	from ultralytics import YOLO
except ImportError:
	YOLO = None

from utils.geometry import iou, extract_head_region


class HelmetDetector:
	"""Detects helmet class using trained YOLO model with IoU-based validation."""

	def __init__(self, model_path, confidence_threshold=0.5, device="cpu"):
		if YOLO is None:
			raise RuntimeError("ultralytics is not installed.")
		self.model_path = model_path
		self.confidence_threshold = float(confidence_threshold)
		self.device = device
		self._model = YOLO(self.model_path)

	def detect(self, frame):
		"""
		Detect helmet objects in frame.
		
		Args:
			frame: Image array
		
		Returns:
			List of helmet bboxes [(x1, y1, x2, y2), ...]
		"""
		if self._model is None:
			return []

		results = self._model.predict(
			frame,
			conf=self.confidence_threshold,
			device=self.device,
			verbose=False,
		)
		helmet_boxes = []
		for result in results:
			for box in result.boxes:
				class_id = int(box.cls[0])
				class_name = self._model.names.get(class_id, str(class_id))
				if class_name.lower() != "helmet":
					continue
				x1, y1, x2, y2 = box.xyxy[0].tolist()
				helmet_boxes.append((float(x1), float(y1), float(x2), float(y2)))

		return helmet_boxes

	def has_helmet_on_person(self, person_bbox, helmet_boxes, iou_threshold=0.3, head_ratio=0.4):
		"""
		Check if person is wearing helmet using IoU-based method.
		Extracts upper 40% of person bbox as head region.
		Checks IoU between helmet box and head region.
		
		Args:
			person_bbox: (x1, y1, x2, y2) person bounding box
			helmet_boxes: List of helmet bboxes
			iou_threshold: Min IoU for helmet to be considered on head (default 0.3)
			head_ratio: Fraction of person height that is head (default 0.4 = upper 40%)
		
		Returns:
			bool: True if helmet detected with sufficient IoU, False otherwise
		"""
		if not helmet_boxes:
			return False

		# Extract head region from person bbox
		head_box = extract_head_region(person_bbox, head_ratio=head_ratio)

		# Check IoU with each helmet
		for helmet_box in helmet_boxes:
			overlap = iou(head_box, helmet_box)
			if overlap >= iou_threshold:
				return True

		return False
