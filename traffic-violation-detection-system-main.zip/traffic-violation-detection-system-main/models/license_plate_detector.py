import random
import string


try:
	import easyocr
except ImportError:
	easyocr = None


class LicensePlateDetector:
	def __init__(
		self,
		confidence_threshold=0.5,
		backend="mock",
		model_path=None,
		device="cpu",
		reader_langs=None,
		min_text_score=0.4,
		seed=99,
	):
		self.confidence_threshold = confidence_threshold
		self.backend = backend
		self.model_path = model_path
		self.device = device
		self.reader_langs = reader_langs or ["en"]
		self.min_text_score = min_text_score
		self._rng = random.Random(seed)
		self._reader = None

		if self.backend == "ocr":
			if easyocr is None:
				raise RuntimeError("easyocr is not installed. Install requirements.txt first.")
			use_gpu = self.device not in ("cpu", "mps")
			self._reader = easyocr.Reader(self.reader_langs, gpu=use_gpu)

	def detect(self, frame, vehicle_detection):
		if self.backend == "mock":
			return self._mock_detect()

		if self._reader is None:
			return None

		x1, y1, x2, y2 = map(int, vehicle_detection["bbox"])
		x1, y1 = max(0, x1), max(0, y1)
		vehicle_crop = frame[y1:y2, x1:x2]
		if vehicle_crop.size == 0:
			return None

		vehicle_rgb = vehicle_crop[:, :, ::-1]
		ocr_results = self._reader.readtext(vehicle_rgb)
		if not ocr_results:
			return None

		best_text = None
		best_score = 0.0
		for _, text, score in ocr_results:
			if score > best_score:
				best_text = text
				best_score = score

		if best_text and best_score >= self.min_text_score:
			return best_text

		return None

	def _mock_detect(self):
		if self._rng.random() < 0.35:
			return None

		letters = "".join(self._rng.choices(string.ascii_uppercase, k=2))
		digits = "".join(self._rng.choices(string.digits, k=4))
		return f"{letters}-{digits}"
