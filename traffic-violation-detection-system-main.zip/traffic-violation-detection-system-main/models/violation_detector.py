import math


class ViolationDetector:
	def __init__(
		self,
		speed_limit_kmh=60,
		red_light=None,
		wrong_way=None,
		illegal_parking=None,
		speeding_repeat_s=5.0,
		traffic_light_state="unknown",
	):
		self.speed_limit_kmh = speed_limit_kmh
		self.red_light = red_light or {}
		self.wrong_way = wrong_way or {}
		self.illegal_parking = illegal_parking or {}
		self.speeding_repeat_s = speeding_repeat_s
		self.traffic_light_state = traffic_light_state

		self._track_state = {}
		self._issued = {
			"speeding": {},
			"red_light": set(),
			"wrong_way": set(),
			"illegal_parking": set(),
		}

	def set_traffic_light_state(self, state):
		"""Update current traffic light state (red/yellow/green/unknown)."""
		self.traffic_light_state = str(state).lower()

	def update(self, track_id, center, speed_kmh, timestamp):
		violations = []
		state = self._track_state.get(track_id, {})
		last_center = state.get("center")
		last_ts = state.get("timestamp")

		if speed_kmh is not None and speed_kmh > self.speed_limit_kmh:
			last_emit = self._issued["speeding"].get(track_id)
			if last_emit is None or (timestamp - last_emit) >= self.speeding_repeat_s:
				violations.append(
					{
						"type": "speeding",
						"detail": f"speed={speed_kmh} limit={self.speed_limit_kmh}",
					}
				)
				self._issued["speeding"][track_id] = timestamp

		if self._red_light_enabled() and last_center is not None:
			if self.traffic_light_state == "red":
				if self._crossed_stop_line(track_id, last_center, center):
					if track_id not in self._issued["red_light"]:
						violations.append({"type": "red_light", "detail": "stop_line_crossed_during_red"})
						self._issued["red_light"].add(track_id)

		if self._wrong_way_enabled() and last_center is not None:
			if self._is_wrong_way(last_center, center):
				if track_id not in self._issued["wrong_way"]:
					violations.append({"type": "wrong_way", "detail": "opposite_direction"})
					self._issued["wrong_way"].add(track_id)

		if self._illegal_parking_enabled():
			if self._is_illegal_parking(track_id, center, speed_kmh, timestamp):
				if track_id not in self._issued["illegal_parking"]:
					violations.append({"type": "illegal_parking", "detail": "dwell_time_exceeded"})
					self._issued["illegal_parking"].add(track_id)

		parking_start = self._track_state.get(track_id, {}).get("parking_start")
		self._track_state[track_id] = {
			"center": center,
			"timestamp": timestamp,
			"line_side": self._line_side(center),
			"parking_start": parking_start,
		}

		return violations

	def _red_light_enabled(self):
		return bool(self.red_light.get("enabled", False)) and self.red_light.get("line")

	def _wrong_way_enabled(self):
		return bool(self.wrong_way.get("enabled", False)) and self.wrong_way.get("allowed_direction")

	def _illegal_parking_enabled(self):
		return bool(self.illegal_parking.get("enabled", False)) and self.illegal_parking.get("zones")

	def _line_side(self, point):
		line = self.red_light.get("line") if self.red_light else None
		if not line or len(line) != 4:
			return None
		x1, y1, x2, y2 = line
		px, py = point
		return math.copysign(1.0, (x2 - x1) * (py - y1) - (y2 - y1) * (px - x1))

	def _crossed_stop_line(self, track_id, last_center, center):
		last_side = self._track_state.get(track_id, {}).get("line_side")
		current_side = self._line_side(center)
		if last_side is None or current_side is None:
			return False
		return last_side != current_side

	def _is_wrong_way(self, last_center, center):
		dy = center[1] - last_center[1]
		movement = abs(dy)
		min_movement = float(self.wrong_way.get("min_movement_px", 5.0))
		if movement < min_movement:
			return False

		allowed_direction = str(self.wrong_way.get("allowed_direction", "down")).lower()
		if allowed_direction == "down":
			return dy < 0
		if allowed_direction == "up":
			return dy > 0
		return False

	def _is_illegal_parking(self, track_id, center, speed_kmh, timestamp):
		threshold = float(self.illegal_parking.get("speed_threshold_kmh", 1.0))
		min_duration = float(self.illegal_parking.get("min_duration_s", 10.0))
		zones = self.illegal_parking.get("zones", [])
		if speed_kmh is None or speed_kmh > threshold:
			self._track_state.setdefault(track_id, {}).pop("parking_start", None)
			return False

		in_zone = any(self._point_in_zone(center, zone) for zone in zones)
		state = self._track_state.setdefault(track_id, {})
		if not in_zone:
			state.pop("parking_start", None)
			return False

		start_ts = state.get("parking_start")
		if start_ts is None:
			state["parking_start"] = timestamp
			return False

		return (timestamp - start_ts) >= min_duration

	def _point_in_zone(self, point, zone):
		if not zone or len(zone) != 4:
			return False
		x1, y1, x2, y2 = zone
		px, py = point
		return min(x1, x2) <= px <= max(x1, x2) and min(y1, y2) <= py <= max(y1, y2)
