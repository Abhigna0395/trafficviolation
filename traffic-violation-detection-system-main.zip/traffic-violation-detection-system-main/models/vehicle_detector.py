try:
	from ultralytics import YOLO
except ImportError:
	YOLO = None


class VehicleDetector:
	"""Detects vehicles using trained YOLO model (real inference only)."""

	def __init__(self, model_path, confidence_threshold=0.5, device="cpu", class_names=None):
		"""
		Initialize vehicle detector.
		
		Args:
			model_path: Path to trained YOLO model weights
			confidence_threshold: Detection confidence threshold
			device: Compute device (cpu, cuda, mps)
			class_names: Optional list of class names to filter (e.g., ['car', 'truck'])
		"""
		if YOLO is None:
			raise RuntimeError("ultralytics is not installed. Install requirements.txt first.")
		
		self.model_path = model_path
		self.confidence_threshold = float(confidence_threshold)
		self.device = device
		self.class_names = set(class_names or [])
		self._model = YOLO(self.model_path)

	def detect(self, frame):
		"""
		Detect vehicles in frame.
		
		Args:
			frame: Image array
		
		Returns:
			List of detections: [{"bbox": (x1, y1, x2, y2), "class_name": str, "confidence": float}, ...]
		"""
		if self._model is None:
			return []

		results = self._model.predict(
			frame,
			conf=self.confidence_threshold,
			device=self.device,
			verbose=False,
		)
		detections = []
		for result in results:
			for box in result.boxes:
				class_id = int(box.cls[0])
				class_name = self._model.names.get(class_id, str(class_id))
				if self.class_names and class_name not in self.class_names:
					continue

				x1, y1, x2, y2 = box.xyxy[0].tolist()
				confidence = float(box.conf[0])
				detections.append(
					{
						"bbox": (float(x1), float(y1), float(x2), float(y2)),
						"confidence": confidence,
						"class_name": class_name,
					}
				)

		return detections

	def detect_people(self, frame):
		"""
		Detect people (person class) in frame.
		
		Args:
			frame: Image array
		
		Returns:
			List of person bboxes [(x1, y1, x2, y2), ...]
		"""
		if self._model is None:
			return []

		results = self._model.predict(
			frame,
			conf=self.confidence_threshold,
			device=self.device,
			verbose=False,
		)
		people = []
		for result in results:
			for box in result.boxes:
				class_id = int(box.cls[0])
				class_name = self._model.names.get(class_id, str(class_id))
				if class_name.lower() != "person":
					continue
				x1, y1, x2, y2 = box.xyxy[0].tolist()
				people.append((float(x1), float(y1), float(x2), float(y2)))

		return people
