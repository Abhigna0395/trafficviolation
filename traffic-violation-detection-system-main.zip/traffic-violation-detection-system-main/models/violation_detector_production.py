"""
Production Smart Traffic Violation Detector.
Detects: No Helmet, Red Light Jump, Wrong Way.
NO SPEED DETECTION.
"""
import time
from collections import deque

from utils.geometry import (
	line_crossing_detection,
	compute_motion_vector_angle,
	angle_difference,
)
from utils.temporal_filter import ConfirmationFilter
from utils.violation_cooldown import ViolationCooldown


class ProductionViolationDetector:
	"""
	Production-ready violation detector.
	Violations: No Helmet, Red Light Jump, Wrong Way.
	"""

	def __init__(
		self,
		red_light=None,
		wrong_way=None,
		red_light_confirmation_frames=3,
		wrong_way_smoothing_frames=5,
		violation_cooldown_s=5.0,
	):
		"""
		Initialize violation detector.
		
		Args:
			red_light: Config dict for red light violation
			wrong_way: Config dict for wrong way violation
			red_light_confirmation_frames: Frames needed to confirm red light jump
			wrong_way_smoothing_frames: Frames for motion vector history
			violation_cooldown_s: Global cooldown between identical violations
		"""
		self.red_light = red_light or {}
		self.wrong_way = wrong_way or {}
		self.traffic_light_state = "unknown"
		self.red_light_confirmation_frames = int(red_light_confirmation_frames)
		self.wrong_way_smoothing_frames = int(wrong_way_smoothing_frames)

		# Track state
		self._track_state = {}  # track_id -> state dict
		
		# Violation confirmation (needs N consecutive frames)
		self._red_light_confirmation = ConfirmationFilter(red_light_confirmation_frames)
		
		# Violation cooldown (prevent duplicates)
		self._cooldown = ViolationCooldown(violation_cooldown_s)
	
	def set_traffic_light_state(self, state):
		"""Update current traffic light state."""
		self.traffic_light_state = str(state).lower()

	def update(self, track_id, center, timestamp, frame_index=0):
		"""
		Update vehicle state and check for violations.
		
		Args:
			track_id: Unique vehicle track ID
			center: Vehicle centroid (x, y)
			timestamp: Frame timestamp
			frame_index: Current frame index for debugging
		
		Returns:
			List of violations: [{"type": str, "detail": str, "severity": str}, ...]
		"""
		violations = []
		
		# Initialize track state if needed
		if track_id not in self._track_state:
			self._track_state[track_id] = {
				"center": center,
				"timestamp": timestamp,
				"positions": deque(maxlen=self.wrong_way_smoothing_frames),
			}
			self._track_state[track_id]["positions"].append((center[0], center[1], timestamp))
			return violations
		
		state = self._track_state[track_id]
		last_center = state.get("center")
		
		# Update position history
		state["positions"].append((center[0], center[1], timestamp))
		state["center"] = center
		state["timestamp"] = timestamp
		
		# 1. RED LIGHT JUMP VIOLATION
		if self._red_light_enabled() and last_center is not None:
			violations.extend(self._check_red_light_jump(track_id, last_center, center, timestamp))
		
		# 2. WRONG WAY VIOLATION
		if self._wrong_way_enabled() and len(state["positions"]) >= 2:
			violations.extend(self._check_wrong_way(track_id, state["positions"], violations, timestamp))
		
		return violations

	def _check_red_light_jump(self, track_id, last_center, curr_center, timestamp):
		"""
		Check for red light jump violation with confirmation system.
		Requires:
		1. Traffic light state == RED
		2. Centroid crosses stop line
		3. Confirmed in N consecutive frames
		"""
		violations = []
		
		if self.traffic_light_state != "red":
			return violations
		
		# Check line crossing
		line = self.red_light.get("line")
		if not line or len(line) != 4:
			return violations
		
		if not line_crossing_detection(last_center, curr_center, line):
			self._red_light_confirmation.reset(track_id)
			return violations
		
		# Check confirmation (must be detected in N consecutive frames)
		confirmed = self._red_light_confirmation.update(track_id, True)
		if not confirmed:
			return violations
		
		# Log only if cooldown allows
		if not self._cooldown.can_log(track_id, "red_light", timestamp):
			return violations
		
		violations.append({
			"type": "red_light",
			"detail": f"crossed stop line during red light (confirmed {self.red_light_confirmation_frames} frames)",
			"severity": "high"
		})
		self._cooldown.log_violation(track_id, "red_light", timestamp)
		
		return violations

	def _check_wrong_way(self, track_id, positions, existing_violations, timestamp):
		"""
		Check for wrong way violation using motion vector angles.
		
		Computes motion angle over last 5 frames and compares with allowed direction.
		"""
		violations = []
		
		if any(v["type"] == "wrong_way" for v in existing_violations):
			return violations
		
		if len(positions) < 2:
			return violations
		
		# Compute motion vector from oldest to newest position
		oldest_x, oldest_y, oldest_t = positions[0]
		newest_x, newest_y, newest_t = positions[-1]
		
		# Compute motion angle
		motion_angle = compute_motion_vector_angle((oldest_x, oldest_y), (newest_x, newest_y))
		
		# Get allowed direction and convert to angle
		allowed_direction = str(self.wrong_way.get("allowed_direction", "down")).lower()
		if allowed_direction == "down":
			allowed_angle = 90.0  # Moving downward (positive y)
		elif allowed_direction == "up":
			allowed_angle = 270.0  # Moving upward (negative y)
		elif allowed_direction == "left":
			allowed_angle = 180.0  # Moving left
		elif allowed_direction == "right":
			allowed_angle = 0.0  # Moving right
		else:
			return violations
		
		# Compute angle difference
		angle_diff = abs(angle_difference(motion_angle, allowed_angle))
		
		# If angle difference > threshold degrees, considered wrong way
		threshold = float(self.wrong_way.get("angle_threshold_deg", 90.0))
		if angle_diff > threshold:
			if self._cooldown.can_log(track_id, "wrong_way", timestamp):
				violations.append({
					"type": "wrong_way",
					"detail": f"motion angle {motion_angle:.1f}° deviates {angle_diff:.1f}° from allowed {allowed_angle:.1f}°",
					"severity": "high"
				})
				self._cooldown.log_violation(track_id, "wrong_way", timestamp)
		
		return violations

	def _red_light_enabled(self):
		"""Check if red light detection is enabled."""
		return bool(self.red_light.get("enabled", False)) and self.red_light.get("line")

	def _wrong_way_enabled(self):
		"""Check if wrong way detection is enabled."""
		return bool(self.wrong_way.get("enabled", False)) and self.wrong_way.get("allowed_direction")
