try:
	import cv2
	import numpy as np
except ImportError:
	cv2 = None
	np = None

try:
	from ultralytics import YOLO
except ImportError:
	YOLO = None

from utils.temporal_filter import MajorityVoter


class TrafficLightDetector:
	"""Detects traffic lights and classifies their state with temporal smoothing."""

	def __init__(self, model_path=None, confidence_threshold=0.5, device="cpu", smoothing_window=5):
		"""
		Initialize traffic light detector.
		
		Args:
			model_path: Path to YOLO model for traffic light detection (optional)
			confidence_threshold: Detection confidence threshold
			device: Compute device (cpu, cuda, mps)
			smoothing_window: Number of frames for temporal smoothing (majority voting)
		"""
		self.model_path = model_path
		self.confidence_threshold = float(confidence_threshold)
		self.device = device
		self.smoothing_window = int(smoothing_window)
		self._model = None

		if self.model_path and YOLO is not None:
			self._model = YOLO(self.model_path)

		# Temporal smoothing using majority voting
		self._state_voter = MajorityVoter(window_size=smoothing_window)

	def detect(self, frame):
		"""
		Detect traffic lights in frame with temporal smoothing.
		
		Args:
			frame: Image array (BGR)
		
		Returns:
			List of traffic light detections: [{"bbox": (...), "state": str}, ...]
		"""
		if self._model is None or cv2 is None:
			return []

		try:
			results = self._model.predict(
				frame,
				conf=self.confidence_threshold,
				device=self.device,
				verbose=False,
			)
			detections = []
			for result in results:
				for box in result.boxes:
					class_id = int(box.cls[0])
					class_name = self._model.names.get(class_id, str(class_id))
					if class_name.lower() not in ["traffic light", "traffic_light"]:
						continue

					x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
					
					# Classify raw state
					raw_state = self._classify_signal_state(frame, (x1, y1, x2, y2))
					
					# Apply temporal smoothing
					smoothed_state = self._state_voter.update(raw_state)
					
					detections.append({
						"bbox": (float(x1), float(y1), float(x2), float(y2)),
						"state": smoothed_state,
						"raw_state": raw_state,
					})
			return detections
		except Exception as e:
			return []

	def _classify_signal_state(self, frame, bbox):
		"""
		Classify traffic light state using HSV color detection with normalized ratios.
		
		Method:
		1. Crop traffic light region from frame
		2. Convert to HSV color space
		3. Create masks for Red, Yellow, Green using HSV ranges
		4. Compute pixel ratio for each color (normalized by total masked pixels)
		5. Return dominant color
		
		Args:
			frame: Image array (BGR)
			bbox: Bounding box (x1, y1, x2, y2)
		
		Returns:
			str: "red", "yellow", "green", or "unknown"
		"""
		if cv2 is None or np is None:
			return "unknown"

		try:
			x1, y1, x2, y2 = bbox
			x1, y1 = max(0, int(x1)), max(0, int(y1))
			x2, y2 = min(frame.shape[1], int(x2)), min(frame.shape[0], int(y2))

			crop = frame[y1:y2, x1:x2]
			if crop.size == 0:
				return "unknown"

			hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)

			# HSV ranges for each color
			# Red wraps around: 0-10 and 170-180
			red_lower1 = np.array([0, 100, 100])
			red_upper1 = np.array([10, 255, 255])
			red_lower2 = np.array([170, 100, 100])
			red_upper2 = np.array([180, 255, 255])
			red_mask = cv2.inRange(hsv, red_lower1, red_upper1) | cv2.inRange(hsv, red_lower2, red_upper2)

			# Yellow: H 20-30
			yellow_lower = np.array([20, 100, 100])
			yellow_upper = np.array([30, 255, 255])
			yellow_mask = cv2.inRange(hsv, yellow_lower, yellow_upper)

			# Green: H 40-80
			green_lower = np.array([40, 100, 100])
			green_upper = np.array([80, 255, 255])
			green_mask = cv2.inRange(hsv, green_lower, green_upper)

			# Count pixels for each color
			red_count = cv2.countNonZero(red_mask)
			yellow_count = cv2.countNonZero(yellow_mask)
			green_count = cv2.countNonZero(green_mask)

			# Compute normalized ratios
			total = red_count + yellow_count + green_count
			if total == 0:
				return "unknown"

			red_ratio = red_count / total
			yellow_ratio = yellow_count / total
			green_ratio = green_count / total

			# Return dominant color
			if red_ratio > yellow_ratio and red_ratio > green_ratio:
				return "red"
			elif yellow_ratio > red_ratio and yellow_ratio > green_ratio:
				return "yellow"
			elif green_ratio > red_ratio and green_ratio > yellow_ratio:
				return "green"
			else:
				return "unknown"

		except Exception as e:
			return "unknown"

	def get_state(self):
		"""Get last smoothed traffic light state."""
		history = self._state_voter.get_history()
		if history:
			return history[-1]
		return "unknown"
