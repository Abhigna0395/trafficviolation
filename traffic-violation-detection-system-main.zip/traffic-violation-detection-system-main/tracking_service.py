import cv2
import numpy as np
from ultralytics import YOLO


class TrackingService:
	def __init__(self, settings):
		self.settings = settings
		self.vehicle_model = YOLO(settings.vehicle_model_path)
		self.helmet_model = YOLO(settings.helmet_model_path)
		traffic_model_path = settings.traffic_light_model_path or "yolov8m.pt"
		self.traffic_model = YOLO(traffic_model_path)

	def _class_threshold_ok(self, class_name: str, confidence: float) -> bool:
		threshold = self.settings.class_conf_thresholds.get(class_name.lower(), self.settings.default_vehicle_conf)
		return confidence >= threshold

	@staticmethod
	def _is_motorcycle(class_name: str) -> bool:
		name = class_name.lower()
		return name in {"motorcycle", "motorbike", "bike", "two_wheeler", "two-wheeler"}

	def _detect_helmets(self, frame: np.ndarray):
		results = self.helmet_model.predict(
			frame,
			conf=self.settings.helmet_model_conf,
			device=self.settings.runtime_device,
			verbose=False,
		)
		helmets = []
		if not results:
			return helmets
		res = results[0]
		if res.boxes is None:
			return helmets

		names = res.names
		for box in res.boxes:
			cls_id = int(box.cls[0].item())
			class_name = str(names.get(cls_id, cls_id)).lower()
			if class_name not in self.settings.helmet_class_names:
				continue
			x1, y1, x2, y2 = box.xyxy[0].tolist()
			helmets.append((float(x1), float(y1), float(x2), float(y2)))
		return helmets

	@staticmethod
	def _hsv_signal_state(frame: np.ndarray, bbox):
		x1, y1, x2, y2 = map(int, bbox)
		x1 = max(0, x1)
		y1 = max(0, y1)
		x2 = min(frame.shape[1], x2)
		y2 = min(frame.shape[0], y2)
		if x2 <= x1 or y2 <= y1:
			return "unknown"

		crop = frame[y1:y2, x1:x2]
		if crop.size == 0:
			return "unknown"

		hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
		v_mask = cv2.inRange(hsv[:, :, 2], 120, 255)

		red_mask1 = cv2.inRange(hsv, (0, 90, 90), (10, 255, 255))
		red_mask2 = cv2.inRange(hsv, (170, 90, 90), (180, 255, 255))
		red_mask = cv2.bitwise_or(red_mask1, red_mask2)

		green_mask = cv2.inRange(hsv, (35, 70, 70), (90, 255, 255))

		red_count = cv2.countNonZero(cv2.bitwise_and(red_mask, v_mask))
		green_count = cv2.countNonZero(cv2.bitwise_and(green_mask, v_mask))
		total = red_count + green_count
		if total < 8:
			return "unknown"

		red_ratio = red_count / total
		green_ratio = green_count / total
		if red_ratio >= 0.58:
			return "red"
		if green_ratio >= 0.58:
			return "green"
		return "unknown"

	def _detect_signal(self, frame: np.ndarray):
		results = self.traffic_model.predict(
			frame,
			conf=self.settings.traffic_light_conf,
			device=self.settings.runtime_device,
			verbose=False,
		)
		if not results:
			return "unknown", None

		res = results[0]
		if res.boxes is None or len(res.boxes) == 0:
			return "unknown", None

		names = res.names
		best_bbox = None
		best_score = -1.0
		for box in res.boxes:
			cls_id = int(box.cls[0].item())
			class_name = str(names.get(cls_id, cls_id)).lower()
			if class_name not in {"traffic light", "traffic_light", "trafficlight"} and cls_id != 9:
				continue
			x1, y1, x2, y2 = box.xyxy[0].tolist()
			area = max(1.0, (x2 - x1) * (y2 - y1))
			conf = float(box.conf[0].item())
			score = conf * area
			if score > best_score:
				best_score = score
				best_bbox = (float(x1), float(y1), float(x2), float(y2))

		if best_bbox is None:
			return "unknown", None

		state = self._hsv_signal_state(frame, best_bbox)
		return state, best_bbox

	def _track_vehicles(self, frame: np.ndarray):
		track_results = self.vehicle_model.track(
			frame,
			persist=True,
			tracker=self.settings.tracker_config,
			conf=self.settings.default_vehicle_conf,
			device=self.settings.runtime_device,
			verbose=False,
		)

		detections = []
		if not track_results or track_results[0].boxes is None:
			return detections

		res = track_results[0]
		ids = res.boxes.id
		if ids is None:
			return detections

		names = res.names
		for box, tid_tensor in zip(res.boxes, ids):
			track_id = int(tid_tensor.item())
			cls_id = int(box.cls[0].item())
			class_name = str(names.get(cls_id, cls_id)).lower()
			conf = float(box.conf[0].item())

			if class_name not in self.settings.vehicle_class_names:
				continue
			if not self._class_threshold_ok(class_name, conf):
				continue

			x1, y1, x2, y2 = box.xyxy[0].tolist()
			bottom_center = ((x1 + x2) * 0.5, y2)
			centroid = ((x1 + x2) * 0.5, (y1 + y2) * 0.5)

			detections.append(
				{
					"track_id": track_id,
					"class_name": class_name,
					"confidence": conf,
					"bbox": (float(x1), float(y1), float(x2), float(y2)),
					"bottom_center": (float(bottom_center[0]), float(bottom_center[1])),
					"centroid": (float(centroid[0]), float(centroid[1])),
					"is_motorcycle": self._is_motorcycle(class_name),
				}
			)
		return detections

	def process_frame(self, frame: np.ndarray):
		resized = cv2.resize(frame, (self.settings.frame_width, self.settings.frame_height), interpolation=cv2.INTER_LINEAR)
		helmets = self._detect_helmets(resized)
		signal_state, signal_bbox = self._detect_signal(resized)
		tracks = self._track_vehicles(resized)
		return resized, tracks, helmets, signal_state, signal_bbox
