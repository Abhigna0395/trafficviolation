# 🚀 Quick Start Guide - Smart Traffic Violation Detection System

## Step-by-Step Setup

### 1. Install Flask (if not already installed)
```bash
pip install flask
```

### 2. Configure Device for GPU
The system is already configured to use GPU (CUDA). It will auto-detect and fallback to CPU if GPU is unavailable.

Current setting in `config.yaml`:
```yaml
detectors:
  device: cuda  # Will use GPU if available, otherwise fallback to CPU
```

### 3. Run the Detection Pipeline
```bash
python main_production.py
```

**What happens:**
- ✅ Processes entire video (no frame limit)
- ✅ Detects vehicles with ByteTrack
- ✅ Detects helmets using IoU method
- ✅ Detects traffic lights with temporal smoothing
- ✅ Detects red light jumps with 3-frame confirmation
- ✅ Detects wrong way violations using motion vectors
- ✅ Draws lanes using Canny + Hough Transform
- ✅ Saves annotated video to `outputs/annotated_video.mp4`
- ✅ Saves evidence images to `outputs/violations/`
- ✅ Logs violations to SQLite database

**Expected Output:**
```
======================================================================
SMART TRAFFIC VIOLATION DETECTION SYSTEM - PRODUCTION
======================================================================
GPU detected: <GPU Name>  (or "GPU not available, using CPU")
Initializing detectors and trackers...
Starting pipeline...
======================================================================
Processing frame 0... (X.X FPS)
Processing frame 30... (X.X FPS)
...
[VIOLATION] Frame 145: RED_LIGHT | Track 5 | crossed stop line...
[VIOLATION] Frame 230: WRONG_WAY | Track 12 | motion angle...
[VIOLATION] Frame 310: NO_HELMET | Track 8 | person without helmet...
...
======================================================================
Pipeline complete!
  Frames processed: 310
  Violations detected: 42
    - No Helmet: 12
    - Red Light: 18
    - Wrong Way: 12
  Elapsed time: 62.5s
  Average FPS: 4.96
  Output video: outputs/annotated_video.mp4
======================================================================
Start web dashboard: python app.py
======================================================================
```

### 4. Launch Web Dashboard
```bash
python app.py
```

**Expected Output:**
```
======================================================================
SMART TRAFFIC VIOLATION DETECTION SYSTEM - WEB DASHBOARD
======================================================================
Dashboard URL: http://127.0.0.1:5000
Press Ctrl+C to stop
======================================================================
 * Serving Flask app 'app'
 * Running on http://127.0.0.1:5000
```

### 5. Access Dashboard
Open your browser and go to:
```
http://127.0.0.1:5000
```

**Dashboard Features:**
- 📊 Real-time violation statistics (Total, No Helmet, Red Light, Wrong Way)
- 📈 Pie chart showing violation distribution
- 📊 Bar chart comparing violation types
- 📋 Recent violations table with evidence images
- 🟢 Live system status indicator
- 🔄 Auto-refresh every 5 seconds

---

## 🎨 Visualization Features

### Annotated Video Output

**Dashboard Panel (Top):**
```
┌───────────────────────────────────────────────────────────────┐
│  TOTAL: 42    NO HELMET: 12    RED LIGHT: 18    WRONG WAY: 12 │
└───────────────────────────────────────────────────────────────┘
```

**Bounding Boxes:**
- 🟢 Green: Normal vehicle
- 🔵 Blue: No Helmet violation
- 🟣 Purple: Red Light Jump violation
- 🔴 Red: Wrong Way violation
- Thickness: 3 pixels

**Labels:**
```
ID: 42
Type: motorcycle
Violation: No Helmet
```

**Traffic Signal Display (Top-Left):**
```
╔═══════════════╗
║ SIGNAL: RED   ║  (in RED color)
╚═══════════════╝
```

**FPS Counter (Top-Right):**
```
┌─────────────┐
│  FPS: 25.3  │
└─────────────┘
```

**Stop Line:**
```
━━━━━━━━━━━━━━━━━━━━━
    STOP LINE
━━━━━━━━━━━━━━━━━━━━━
```

**Lane Detection:**
- Yellow lane markings
- Transparent overlay (alpha = 0.7)

---

## 🔧 Configuration

### Change Stop Line Position
Edit `config/config.yaml`:
```yaml
violation:
  red_light:
    line: [300, 450, 900, 450]  # [x1, y1, x2, y2]
```

### Change Allowed Direction
```yaml
violation:
  wrong_way:
    allowed_direction: down  # down / up / left / right
    angle_threshold_deg: 90
```

### Enable/Disable Violations
```yaml
violation:
  red_light:
    enabled: true  # Set to false to disable
  wrong_way:
    enabled: true
```

### Process Specific Frame Range
```yaml
processing:
  max_frames: 100  # Process only first 100 frames (or ~ for all)
  frame_skip: 1    # Process every frame (or 2 for every other frame)
```

---

## 📊 Database Queries

### View All Violations
```bash
python -c "import sqlite3; conn = sqlite3.connect('data/violations.db'); cursor = conn.cursor(); cursor.execute('SELECT * FROM violations'); [print(row) for row in cursor.fetchall()]"
```

### Count Violations by Type
```bash
python -c "import sqlite3; conn = sqlite3.connect('data/violations.db'); cursor = conn.cursor(); cursor.execute('SELECT violation_type, COUNT(*) FROM violations GROUP BY violation_type'); [print(row) for row in cursor.fetchall()]"
```

---

## 🐛 Troubleshooting

### Problem: "ValueError: Invalid CUDA device"
**Solution:** Device is already set to handle this automatically. The system will use GPU if available, CPU otherwise.

### Problem: "ImportError: No module named 'flask'"
**Solution:**
```bash
pip install flask
```

### Problem: "FileNotFoundError: [Errno 2] No such file or directory: 'runs/detect/train7/weights/best.pt'"
**Solution:** Update model paths in `config/config.yaml` to point to your actual model locations.

### Problem: Dashboard shows "0 violations"
**Solution:** Run `python main_production.py` first to process video and populate database.

### Problem: Slow processing speed
**Solution:** 
1. Install CUDA-enabled PyTorch for GPU acceleration
2. Reduce video resolution in config
3. Increase `frame_skip` value (process every 2nd or 3rd frame)

---

## 📁 Output Files

After running the pipeline:

```
outputs/
├── annotated_video.mp4          # Main output video with all visualizations
└── violations/                  # Evidence images
    ├── no_helmet_8_123.jpg
    ├── red_light_5_145.jpg
    ├── wrong_way_12_230.jpg
    └── ...

data/
└── violations.db                # SQLite database with all violations

logs/
└── traffic_system_YYYYMMDD.log  # Detailed logs
```

---

## 🎯 What's Different from Previous Version?

### ✅ Added:
- **Flask backend** with REST API endpoints
- **Modern web dashboard** with Bootstrap 5 + Chart.js
- **Lane detection** using Canny + Hough Transform
- **Dashboard panel** showing live violation counts on video
- **Clean label format** (ID / Type / Violation)
- **Production annotator** with professional visualization
- **No speed detection** (completely removed)

### ✅ Kept:
- **ByteTrack** persistent tracking
- **IoU-based** helmet detection
- **Temporal smoothing** for traffic lights
- **3-frame confirmation** for red light jumps
- **Motion vector** wrong way detection
- **Violation cooldown** system
- **SQLite database** logging
- **Evidence saving**

### ❌ Removed:
- Speed detection and estimation
- Speed limit checking
- Speeding violations
- Illegal parking (speed-based)
- HomographySpeedEstimator

---

## 🏆 System Capabilities

✅ **Real-time Detection:** Process video and detect violations in real-time  
✅ **Persistent Tracking:** ByteTrack maintains IDs across entire video  
✅ **No False Positives:** 3-frame confirmation for red light jumps  
✅ **Production Algorithms:** IoU-based helmet, motion vector wrong way  
✅ **Web Monitoring:** Live dashboard with auto-refresh  
✅ **Evidence Management:** Automatic image capture and database logging  
✅ **Scalable:** Clean OOP architecture, easy to extend  
✅ **GPU Accelerated:** Auto-detect and use CUDA if available  

---

**System is now production-ready and presentation-ready! 🚀**
