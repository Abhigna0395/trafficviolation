# Smart Traffic Violation Detection System

**Production-Ready AI System for Real-Time Traffic Violation Detection and Monitoring**

---

## 🚀 Overview

This is a complete, production-ready Smart Traffic Violation Detection System built with:
- **Python**
- **OpenCV**
- **Ultralytics YOLOv8**
- **Flask**
- **SQLite**
- **Bootstrap 5**
- **Chart.js**

The system detects and monitors traffic violations in real-time with a modern web dashboard for visualization and analytics.

---

## ✨ Features

### Detection Modules

1. **Vehicle Detection**
   - YOLOv8-based detection (car, truck, bus, motorcycle)
   - ByteTrack integration for persistent tracking IDs
   - Real-time object tracking across frames

2. **Helmet Detection**
   - IoU-based validation (no heuristics)
   - Extracts top 40% of person bounding box as head region
   - Computes IoU between helmet and head region
   - Flags violation if IoU < 0.3

3. **Traffic Light Detection**
   - YOLO-based traffic light detection
   - HSV color space analysis (red, yellow, green)
   - Pixel ratio normalization
   - Temporal smoothing with 5-frame majority voting

4. **Red Light Jump Detection**
   - Stop line tracking from config
   - Centroid-based line crossing detection
   - 3-frame confirmation system (no false positives)
   - Only flags when traffic light is RED

5. **Wrong Way Detection**
   - Motion vector analysis using last 5 centroid positions
   - atan2-based angle computation
   - Compares with allowed direction from config
   - Flags when deviation exceeds 90° threshold

6. **Lane Detection**
   - Canny edge detection + Hough Transform
   - ROI-based masking
   - Transparent overlay visualization

### Visualization

- **Clean Bounding Boxes**
  - Green: Normal vehicle
  - Blue: No Helmet
  - Purple: Red Light Jump
  - Red: Wrong Way
  - Thickness: 3px

- **Clean Labels**
  ```
  ID: <track_id>
  Type: <vehicle_class>
  Violation: <type if exists>
  ```

- **Dashboard Panel** (Top)
  - Total Violations Count
  - No Helmet Count
  - Red Light Jump Count
  - Wrong Way Count

- **Traffic Signal Display** (Top-Left)
  - Shows: RED / GREEN / YELLOW
  - Large bold font with matching color

- **FPS Counter** (Top-Right)
  - Real-time FPS display

- **Stop Line**
  - Thick white line with "STOP LINE" label

### Web Dashboard

- **Modern Dark Theme UI**
- **Real-time Statistics**
  - Total violations
  - Violation breakdown (pie chart + bar chart)
  - Recent violations table
- **Auto-refresh every 5 seconds**
- **Evidence image preview**
- **Responsive design (Bootstrap 5)**

---

## 📁 Project Structure

```
traffic-violation-system/
├── config/
│   └── config.yaml                 # Configuration file
├── models/
│   ├── vehicle_detector.py         # YOLOv8 vehicle detection
│   ├── helmet_detector.py          # IoU-based helmet detection
│   ├── traffic_light_detector.py   # Traffic light detection w/ temporal smoothing
│   ├── violation_detector_production.py  # Violation logic (no speed)
│   └── lane_detector.py            # Canny + Hough lane detection
├── utils/
│   ├── byte_tracker.py             # ByteTrack persistent tracking
│   ├── production_annotator.py     # Production visualization
│   ├── geometry.py                 # IoU, line crossing, angles
│   ├── temporal_filter.py          # Majority voting, confirmation
│   ├── violation_cooldown.py       # Duplicate prevention
│   ├── video_processor.py          # Video I/O
│   ├── database.py                 # SQLite operations
│   └── logger.py                   # Logging system
├── templates/
│   └── dashboard.html              # Web dashboard UI
├── app.py                          # Flask backend
├── main_production.py              # Main production pipeline
├── requirements.txt                # Dependencies
└── data/
    ├── sample.mp4                  # Input video
    └── violations.db               # SQLite database
```

---

## 🔧 Installation

### 1. Clone Repository

```bash
cd traffic-violation-system
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

**For GPU Support (Recommended):**
```bash
# CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# CUDA 12.1
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

### 3. Install Flask

```bash
pip install flask
```

---

## 📝 Configuration

Edit `config/config.yaml`:

```yaml
paths:
  input_video: data/sample.mp4
  output_dir: outputs
  evidence_dir: outputs/violations
  db_path: data/violations.db

models:
  vehicle_model: runs/detect/train7/weights/best.pt
  helmet_model: runs/detect/train6/weights/best.pt

detectors:
  vehicle_confidence: 0.5
  helmet_confidence: 0.5
  traffic_light_confidence: 0.5
  device: cuda  # cuda for GPU, cpu for CPU

violation:
  red_light:
    enabled: true
    line: [300, 450, 900, 450]  # Stop line (x1, y1, x2, y2)
    confirmation_frames: 3

  wrong_way:
    enabled: true
    allowed_direction: down  # down / up / left / right
    angle_threshold_deg: 90

processing:
  max_frames: ~  # null = process entire video
  frame_skip: 1
  output_fps: 30
```

---

## ▶️ Usage

### 1. Run Detection Pipeline

```bash
python main_production.py
```

**Output:**
- Annotated video: `outputs/annotated_video.mp4`
- Evidence images: `outputs/violations/`
- Database: `data/violations.db`

### 2. Launch Web Dashboard

```bash
python app.py
```

**Access:** [http://127.0.0.1:5000](http://127.0.0.1:5000)

**Features:**
- Real-time violation statistics
- Pie chart + bar chart visualization
- Recent violations table
- Evidence image preview
- Auto-refresh every 5 seconds

---

## 🎯 Key Algorithms

### 1. Helmet Detection (IoU-based)
```python
def has_helmet_on_person(person_bbox, helmet_results):
    head_region = extract_head_region(person_bbox, head_ratio=0.4)
    for helmet in helmet_results:
        if iou(helmet["bbox"], head_region) >= 0.3:
            return True
    return False
```

### 2. Red Light Jump (3-Frame Confirmation)
```python
if traffic_light_state == "red":
    if line_crossing_detection(last_center, curr_center, stop_line):
        confirmed = confirmation_filter.update(track_id, True)
        if confirmed:  # Must be detected in 3 consecutive frames
            flag_red_light_violation()
```

### 3. Wrong Way Detection (Motion Vector Angles)
```python
motion_angle = atan2(dy, dx)
allowed_angle = 90.0  # Downward direction
angle_diff = abs(angle_difference(motion_angle, allowed_angle))
if angle_diff > 90.0:
    flag_wrong_way_violation()
```

### 4. ByteTrack (Persistent Tracking)
- Hungarian algorithm for centroid matching
- Max distance: 50 pixels
- Track aging: 30 frames
- Persistent IDs across entire video

### 5. Temporal Smoothing (Traffic Light)
- Majority voting over last 5 frames
- Reduces false positives from lighting changes

---

## 📊 Database Schema

```sql
CREATE TABLE violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    track_id INTEGER,
    plate_number TEXT,
    violation_type TEXT NOT NULL,
    location TEXT,
    image_path TEXT,
    status TEXT DEFAULT 'pending',
    detail TEXT
);
```

---

## 🎨 Dashboard Screenshots

### Real-time Stats
- Large violation counter cards
- Animated status indicator
- Color-coded violation types

### Charts
- Pie chart: Violation distribution
- Bar chart: Violation comparison

### Recent Violations Table
- Timestamp
- Track ID
- Violation type badge
- Evidence image thumbnail
- Status indicator

---

## 🚀 Performance

### With GPU (CUDA):
- **FPS:** 25-30 (depending on GPU)
- **Processing Time:** ~1x video duration

### With CPU:
- **FPS:** 1-3 (depending on CPU)
- **Processing Time:** ~10x video duration

**Recommendation:** Use CUDA-enabled PyTorch for production deployment.

---

## 🔥 Production Features

✅ **No Speed Detection** (removed completely)  
✅ **ByteTrack** persistent tracking  
✅ **IoU-based** helmet detection (no heuristics)  
✅ **Temporal smoothing** for traffic lights  
✅ **3-frame confirmation** for red light jumps  
✅ **Motion vector** wrong way detection  
✅ **Lane detection** visualization  
✅ **Violation cooldown** (5 seconds)  
✅ **Flask backend** with REST API  
✅ **Modern web dashboard** with Chart.js  
✅ **SQLite database** for persistence  
✅ **Evidence saving** with timestamps  
✅ **Auto-refresh** dashboard (5s)  
✅ **Responsive UI** (Bootstrap 5)  
✅ **Dark theme** professional design  
✅ **Clean OOP** architecture  
✅ **GPU auto-detection**  
✅ **Error handling** and logging  

---

## 📦 Dependencies

- Python 3.8+
- OpenCV
- PyTorch (with CUDA support recommended)
- Ultralytics YOLOv8
- Flask
- NumPy
- SciPy
- EasyOCR
- PyYAML
- Bootstrap 5
- Chart.js

---

## 🛠️ Troubleshooting

### Issue: CUDA not available

**Solution:** Install CUDA-enabled PyTorch:
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

### Issue: Database locked

**Solution:** Close Flask app before running pipeline again.

### Issue: Video not processing

**Solution:** Check `config.yaml` for correct video path.

---

## 📞 Support

For issues, please check:
1. Python version (3.8+)
2. CUDA installation (for GPU)
3. Model paths in config.yaml
4. Video path and format

---

## 🎓 Technical Details

**Architecture:** Modular OOP with clean separation of concerns  
**Detection:** YOLOv8 with ByteTrack tracking  
**Violation Logic:** Production algorithms (no heuristics)  
**Visualization:** OpenCV with cv2.addWeighted for transparency  
**Backend:** Flask REST API with SQLite  
**Frontend:** Bootstrap 5 + Chart.js with dark theme  

---

## 🏆 Production Ready

This system is **presentation-ready** and **production-ready** with:
- Professional UI/UX
- Real-time monitoring
- Database persistence
- Evidence documentation
- Clean code architecture
- Comprehensive logging
- Error handling
- Performance optimization

---

**Built with ❤️ for Smart Traffic Management**
