"""
Production-grade traffic violation detection system.
Advanced algorithms with real-time processing.

Detections:
- Vehicle tracking with ByteTrack
- Helmet detection with IoU validation
- Traffic light detection with temporal smoothing
- Speeding detection with homography
- Red light jump with confirmation
- Wrong way with motion vector angles
"""

import os
import time
import yaml
import torch

try:
	import cv2
except ImportError:
	cv2 = None

from models.vehicle_detector import VehicleDetector
from models.helmet_detector import HelmetDetector
from models.license_plate_detector import LicensePlateDetector
from models.traffic_light_detector import TrafficLightDetector
from models.violation_detector_advanced import AdvancedViolationDetector
from utils.byte_tracker import ByteTracker
from utils.speed_estimator_advanced import HomographySpeedEstimator
from utils.advanced_annotator import AdvancedAnnotator
from utils.evidence_saver import EvidenceSaver
from utils.database import ViolationDatabase
from utils.video_processor import VideoProcessor
from utils.logger import Logger


def load_config(config_path):
	"""Load YAML configuration."""
	with open(config_path, "r", encoding="utf-8") as file:
		return yaml.safe_load(file)


def auto_detect_device(logger=None):
	"""Auto-detect GPU availability."""
	if logger is None:
		logger = Logger().get_logger()
	
	if torch.cuda.is_available():
		device = "cuda"
		logger.info(f"GPU detected: {torch.cuda.get_device_name(0)}")
	else:
		device = "cpu"
		logger.info("GPU not available, using CPU")
	return device


def run_advanced_pipeline(config, logger=None):
	"""
	Run advanced traffic violation detection pipeline.
	
	Args:
		config: Configuration dictionary
		logger: Logger instance (optional, creates default if not provided)
	
	Pipeline:
	1. Load detectors and trackers
	2. Process video frames
	3. Detect vehicles, helmets, traffic lights
	4. Track vehicles with ByteTrack
	5. Estimate speed (homography-based)
	6. Check violations (advanced algorithms)
	7. Annotate and save output
	"""
	
	# Initialize logger if not provided
	if logger is None:
		logger = Logger().get_logger()
	
	paths = config.get("paths", {})
	models_cfg = config.get("models", {})
	detectors_cfg = config.get("detectors", {})
	violation_cfg = config.get("violation", {})
	processing = config.get("processing", {})

	# Ensure output directories exist
	output_dir = paths.get("output_dir", "outputs")
	evidence_dir = paths.get("evidence_dir", "outputs/violations")
	os.makedirs(output_dir, exist_ok=True)
	os.makedirs(evidence_dir, exist_ok=True)

	logger.info("=" * 70)
	logger.info("TRAFFIC VIOLATION DETECTION SYSTEM - ADVANCED PIPELINE")
	logger.info("=" * 70)

	# Auto-detect device
	device = auto_detect_device(logger)

	logger.info("Initializing detectors and trackers...")

	# Load detectors
	vehicle_detector = VehicleDetector(
		model_path=models_cfg.get("vehicle_model"),
		confidence_threshold=detectors_cfg.get("vehicle_confidence", 0.5),
		device=device,
		class_names=detectors_cfg.get("vehicle_classes"),
	)

	helmet_detector = HelmetDetector(
		model_path=models_cfg.get("helmet_model"),
		confidence_threshold=detectors_cfg.get("helmet_confidence", 0.5),
		device=device,
	)

	plate_detector = LicensePlateDetector(
		confidence_threshold=detectors_cfg.get("plate_confidence", 0.5),
		backend=detectors_cfg.get("plate_backend", "ocr"),
		device=device,
		reader_langs=detectors_cfg.get("plate_ocr_langs", ["en"]),
		min_text_score=detectors_cfg.get("plate_ocr_min_score", 0.4),
	)

	traffic_light_detector = TrafficLightDetector(
		model_path=models_cfg.get("traffic_light_model"),
		confidence_threshold=detectors_cfg.get("traffic_light_confidence", 0.5),
		device=device,
		smoothing_window=processing.get("traffic_light_smoothing_window", 5),
	)

	# Advanced tracking
	tracker = ByteTracker(
		max_distance=processing.get("max_track_distance", 50),
		max_age=processing.get("max_track_missed", 30),
	)

	# Speed estimation
	speed_estimator = HomographySpeedEstimator(
		pixels_per_meter=processing.get("pixels_per_meter", 8.0),
		fps=processing.get("output_fps", 30.0),
		smoothing_window=processing.get("speed_smoothing_window", 5),
	)

	# Advanced violation detector
	violation_detector = AdvancedViolationDetector(
		speed_limit_kmh=violation_cfg.get("speed_limit_kmh", 60),
		red_light=violation_cfg.get("red_light", {}),
		wrong_way=violation_cfg.get("wrong_way", {}),
		illegal_parking=violation_cfg.get("illegal_parking", {}),
		traffic_light_state="unknown",
		red_light_confirmation_frames=violation_cfg.get("red_light_confirmation_frames", 3),
		wrong_way_smoothing_frames=processing.get("wrong_way_smoothing_frames", 5),
		violation_cooldown_s=violation_cfg.get("violation_cooldown_s", 5.0),
	)

	# Annotator
	annotator = AdvancedAnnotator(
		font_scale=processing.get("annotation_font_scale", 0.6),
		line_thickness=processing.get("annotation_line_thickness", 2),
	)

	# Utilities
	evidence_saver = EvidenceSaver(evidence_dir)
	database = ViolationDatabase(paths.get("db_path", "data/violations.db"))

	# Video processor
	processor = VideoProcessor(
		paths.get("input_video", "data/sample.mp4"),
		max_frames=processing.get("max_frames"),
		frame_skip=processing.get("frame_skip", 1),
	)

	output_video_path = os.path.join(output_dir, "annotated_video.mp4")
	output_fps = processing.get("output_fps", 30)
	writer = None

	logger.info("Starting pipeline...")
	logger.info(f"Speed limit: {violation_cfg.get('speed_limit_kmh', 60)} km/h")
	logger.info(f"Device: {device}")
	logger.info(f"Red light confirmation: {violation_cfg.get('red_light_confirmation_frames', 3)} frames")
	logger.info("-" * 70)

	frame_count = 0
	violation_count = 0
	start_time = time.time()

	for frame_index, frame, timestamp in processor.iter_frames():
		frame_count += 1
		loop_start = time.time()

		# Log progress
		if frame_count % 30 == 0:
			logger.info(f"[Frame {frame_index:5d}] Processing...")

		# Initialize video writer
		if writer is None:
			writer = processor.create_writer(output_video_path, frame.shape, fps=output_fps)

		# Real inference
		people_detections = vehicle_detector.detect_people(frame)
		helmet_detections = helmet_detector.detect(frame)
		vehicle_detections = vehicle_detector.detect(frame)

		# Detect traffic lights with temporal smoothing
		traffic_lights = []
		try:
			traffic_lights = traffic_light_detector.detect(frame)
			if traffic_lights:
				traffic_light_state = traffic_lights[0].get("state", "unknown")
				violation_detector.set_traffic_light_state(traffic_light_state)
		except Exception as e:
			logger.warning(f"Traffic light detection failed: {e}")
			traffic_light_state = "unknown"

		# Compute centers for vehicle detections (required by ByteTracker)
		for detection in vehicle_detections:
			bbox = detection.get("bbox")
			if bbox:
				x1, y1, x2, y2 = bbox
				detection["center"] = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)

		# Track vehicles
		tracked_detections = tracker.update(vehicle_detections, frame_index)

		# Prepare output detections with violations
		output_detections = []

		for detection in tracked_detections:
			track_id = detection.get("track_id")
			center = detection.get("center")
			bbox = detection.get("bbox")

			# Speed estimation
			speed_kmh = speed_estimator.update(track_id, center, timestamp)

			# Check violations
			violations = violation_detector.update(
				track_id,
				center,
				speed_kmh,
				timestamp,
				frame_index=frame_index,
			)

			# Check for helmet on motorcycles
			if detection.get("class_name", "").lower() == "motorcycle":
				rider_found = False
				for person_bbox in people_detections:
					px1, py1, px2, py2 = person_bbox
					vx1, vy1, vx2, vy2 = bbox
					# Check if person is inside vehicle
					if vx1 <= (px1 + px2) / 2 <= vx2 and vy1 <= (py1 + py2) / 2 <= vy2:
						rider_found = True
						# Check helmet with IoU method
						if not helmet_detector.has_helmet_on_person(person_bbox, helmet_detections, iou_threshold=0.3):
							violations.append({
								"type": "no_helmet",
								"detail": "helmet not detected on rider",
								"severity": "high"
							})
						break

			# Prepare output detection
			out_det = {
				"track_id": track_id,
				"bbox": bbox,
				"center": center,
				"class_name": detection.get("class_name"),
				"confidence": detection.get("confidence"),
				"speed_kmh": speed_kmh,
				"violations": violations,
			}
			output_detections.append(out_det)

			# Log and save violations
			if violations:
				plate_text = None
				try:
					plate_text = plate_detector.detect(frame, detection)
				except Exception as e:
					logger.debug(f"Plate detection failed: {e}")

				for violation in violations:
					violation_type = violation.get("type")
					severity = violation.get("severity", "medium")
					detail = violation.get("detail", "")

					# Save evidence image
					evidence_path = evidence_saver.save_violation(
						frame,
						track_id,
						violation_type,
						frame_index,
						plate_text,
					)

					# Log to database
					database.insert_violation(
						track_id=track_id,
						plate_number=plate_text,
						violation_type=violation_type,
						speed_kmh=speed_kmh,
						frame_index=frame_index,
						vehicle_class=detection.get("class_name"),
						violation_detail=detail,
						bbox=bbox,
					)

					violation_count += 1

					logger.warning(
						f"[VIOLATION] Frame {frame_index}: {violation_type.upper()} "
						f"(severity:{severity}) | Track {track_id} | "
						f"Speed {speed_kmh:.1f} km/h | Plate {plate_text or 'N/A'} | "
						f"{detail}"
					)
					if evidence_path:
						logger.info(f"  Evidence saved: {evidence_path}")

		# Compute FPS
		loop_time = time.time() - loop_start
		fps = annotator.compute_fps(time.time())

		# Annotate frame
		frame = annotator.annotate_frame(
			frame,
			output_detections,
			traffic_light_state=traffic_light_state if traffic_lights else "unknown",
			fps=fps,
		)

		# Write output video
		if writer is not None:
			writer.write(frame)

	# Cleanup
	if writer is not None:
		writer.release()
		logger.info(f"Video saved: {output_video_path}")

	elapsed = time.time() - start_time
	logger.info("=" * 70)
	logger.info(f"Pipeline complete!")
	logger.info(f"  Frames processed: {frame_count}")
	logger.info(f"  Violations detected: {violation_count}")
	logger.info(f"  Elapsed time: {elapsed:.2f}s")
	logger.info(f"  Processing rate: {frame_count / max(elapsed, 0.1):.1f} fps")
	logger.info("=" * 70)


if __name__ == "__main__":
	try:
		config_path = os.path.join("config", "config.yaml")
		cfg = load_config(config_path)
		logger = Logger().get_logger()
		run_advanced_pipeline(cfg, logger=logger)
	except KeyboardInterrupt:
		logger.info("\nPipeline interrupted by user")
	except Exception as e:
		logger.error(f"Pipeline error: {e}", exc_info=True)
		raise
