from ultralytics import YOLO
import cv2

model = YOLO("train6/weights/best.pt")


img = cv2.imread("test1.avif")

results = model(img)

results[0].plot()
cv2.imshow("test", results[0].plot())
cv2.waitKey(0)
