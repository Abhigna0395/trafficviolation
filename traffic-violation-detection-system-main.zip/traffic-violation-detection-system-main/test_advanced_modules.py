#!/usr/bin/env python
"""Quick test of advanced system modules."""

from utils.byte_tracker import ByteTracker
from utils.speed_estimator_advanced import HomographySpeedEstimator
from utils.temporal_filter import MajorityVoter
from utils.violation_cooldown import ViolationCooldown
from utils.geometry import iou, extract_head_region, line_crossing_detection
import time

print("=" * 70)
print("TESTING ADVANCED SYSTEM MODULES")
print("=" * 70)

# Test 1: ByteTracker
print("\n1. ByteTracker")
tracker = ByteTracker(max_distance=50, max_age=30)
detections = [
    {'bbox': (100, 100, 200, 200), 'center': (150, 150), 'class_name': 'car', 'confidence': 0.9},
    {'bbox': (300, 300, 400, 400), 'center': (350, 350), 'class_name': 'car', 'confidence': 0.8},
]
results = tracker.update(detections, frame_index=0)
print(f"  ✓ Frame 0: {len(results)} tracks")

detections = [
    {'bbox': (105, 105, 205, 205), 'center': (155, 155), 'class_name': 'car', 'confidence': 0.9},
]
results = tracker.update(detections, frame_index=1)
print(f"  ✓ Frame 1: {len(results)} tracks (IDs: {[r['track_id'] for r in results]})")

# Test 2: HomographySpeedEstimator
print("\n2. HomographySpeedEstimator")
speed_est = HomographySpeedEstimator(pixels_per_meter=8.0, fps=30.0, smoothing_window=5)
t0 = time.time()
speed1 = speed_est.update(track_id=1, centroid=(100, 100), timestamp=t0)
print(f"  ✓ Position 1: speed = {speed1:.2f} km/h")

t1 = time.time() + 0.033  # 30 FPS
speed2 = speed_est.update(track_id=1, centroid=(110, 100), timestamp=t1)
print(f"  ✓ Position 2: speed = {speed2:.2f} km/h (moved 10 pixels)")

# Test 3: MajorityVoter
print("\n3. MajorityVoter (Temporal Smoothing)")
voter = MajorityVoter(window_size=5)
states = ['red', 'red', 'red', 'yellow', 'green']
for state in states:
    result = voter.update(state)
    print(f"  Input: {state:7s} -> Vote: {result}")

# Test 4: ViolationCooldown
print("\n4. ViolationCooldown")
cooldown = ViolationCooldown(cooldown_duration=5.0)
t = time.time()
can_log = cooldown.can_log(track_id=1, violation_type='speeding', current_time=t)
print(f"  ✓ First violation (t=0): can_log = {can_log}")

cooldown.log_violation(track_id=1, violation_type='speeding', current_time=t)
can_log = cooldown.can_log(track_id=1, violation_type='speeding', current_time=t)
print(f"  ✓ Second violation (t=0, same): can_log = {can_log}")

can_log = cooldown.can_log(track_id=1, violation_type='speeding', current_time=t + 3)
print(f"  ✓ Third violation (t=3, < cooldown): can_log = {can_log}")

can_log = cooldown.can_log(track_id=1, violation_type='speeding', current_time=t + 6)
print(f"  ✓ Fourth violation (t=6, > cooldown): can_log = {can_log}")

# Test 5: Geometry
print("\n5. Geometry Utilities")
iou_val = iou((100, 100, 200, 200), (120, 110, 180, 160))
print(f"  ✓ IoU test: {iou_val:.3f}")

head_reg = extract_head_region((100, 50, 200, 300), head_ratio=0.4)
height = int(head_reg[3] - head_reg[1])
print(f"  ✓ Head region extraction: height={height} (40% of 250)")

crossed = line_crossing_detection(
    prev_point=(400, 100),
    curr_point=(400, 500),
    line=(300, 300, 500, 300)
)
print(f"  ✓ Line crossing detection: crossed={crossed}")

print("\n" + "=" * 70)
print("ALL TESTS PASSED")
print("=" * 70)
