import math


class LaneService:
	def __init__(self, lane_boundaries_x, persist_frames=3, min_displacement_px=40.0, min_track_age_frames=12):
		if len(lane_boundaries_x) < 2:
			raise ValueError("lane_boundaries_x must contain at least two boundaries")
		self.lane_boundaries_x = list(lane_boundaries_x)
		self.persist_frames = int(max(1, persist_frames))
		self.min_displacement_px = float(min_displacement_px)
		self.min_track_age_frames = int(max(1, min_track_age_frames))

	def lane_index_from_x(self, x_value: float) -> int | None:
		for idx in range(len(self.lane_boundaries_x) - 1):
			left = self.lane_boundaries_x[idx]
			right = self.lane_boundaries_x[idx + 1]
			if left <= x_value < right:
				return idx
		if x_value == self.lane_boundaries_x[-1]:
			return len(self.lane_boundaries_x) - 2
		return None

	@staticmethod
	def _distance(p1, p2):
		return math.hypot(p2[0] - p1[0], p2[1] - p1[1])

	@staticmethod
	def _smoothed_bottom_center(memory, fallback_point):
		if not memory.centroid_history:
			return fallback_point
		history = list(memory.centroid_history)[-3:]
		x_avg = sum(p[0] for p in history) / len(history)
		y_avg = sum(p[1] for p in history) / len(history)
		return (x_avg, y_avg)

	def update_track_lane(self, memory, bottom_center: tuple[float, float]) -> bool:
		new_confirmed = False
		if memory.lane_violation_confirmed:
			return False

		if memory.frames_seen < self.min_track_age_frames:
			memory.lane_change_counter = 0
			memory.pending_lane_index = None
			memory.pending_start_point = None
			return False

		smoothed_center = self._smoothed_bottom_center(memory, bottom_center)
		x_val = smoothed_center[0]
		current_lane = self.lane_index_from_x(x_val)
		if current_lane is None:
			memory.lane_change_counter = 0
			memory.pending_lane_index = None
			memory.pending_start_point = None
			return False

		if memory.lane_index is None:
			memory.previous_lane = None
			memory.lane_index = current_lane
			memory.pending_lane_index = None
			memory.pending_start_point = None
			memory.lane_change_counter = 0
			return False

		if current_lane == memory.lane_index:
			memory.pending_lane_index = None
			memory.pending_start_point = None
			memory.lane_change_counter = 0
			return False

		if memory.pending_lane_index != current_lane:
			memory.pending_lane_index = current_lane
			memory.pending_start_point = smoothed_center
			memory.lane_change_counter = 1
			return False

		memory.lane_change_counter += 1
		displacement = self._distance(memory.pending_start_point, smoothed_center) if memory.pending_start_point else 0.0

		if memory.lane_change_counter >= self.persist_frames and displacement >= self.min_displacement_px:
			memory.lane_violation_confirmed = True
			memory.violation_type = "LANE_CHANGE"
			memory.previous_lane = memory.lane_index
			memory.lane_index = current_lane
			memory.pending_lane_index = None
			memory.pending_start_point = None
			memory.lane_change_counter = 0
			new_confirmed = True

		return new_confirmed
